-- Aplicar somente após revisão e autorização. Não modifica dados existentes.
begin;
create or replace function public.salvar_variacao(p_produto_id integer,p_id uuid,p_dados jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare v public.produto_variacoes;
begin
  perform 1 from public.produtos where id=p_produto_id for update;
  if not found then raise exception 'Produto não encontrado.'; end if;
  if p_id is null then
    insert into public.produto_variacoes(produto_id,tipo,nome,sku,estoque,preco,preco_promocional,imagem,ativo)
    values(p_produto_id,p_dados->>'tipo',btrim(p_dados->>'nome'),nullif(btrim(p_dados->>'sku'),''),
      (p_dados->>'estoque')::integer,(p_dados->>'preco')::numeric,(p_dados->>'preco_promocional')::numeric,
      p_dados->>'imagem',(p_dados->>'ativo')::boolean) returning * into v;
  else
    select * into v from public.produto_variacoes where id=p_id and produto_id=p_produto_id for update;
    if not found then raise exception 'Variação não encontrada.'; end if;
    if p_dados->>'atualizado_em_original' is null or (p_dados->>'atualizado_em_original')::timestamptz is distinct from v.atualizado_em then
      raise exception 'A variação mudou durante a edição. Recarregue antes de salvar.';
    end if;
    update public.produto_variacoes set tipo=p_dados->>'tipo',nome=btrim(p_dados->>'nome'),sku=nullif(btrim(p_dados->>'sku'),''),
      estoque=case when p_dados ? 'estoque' then (p_dados->>'estoque')::integer else estoque end,preco=(p_dados->>'preco')::numeric,preco_promocional=(p_dados->>'preco_promocional')::numeric,
      imagem=p_dados->>'imagem',ativo=(p_dados->>'ativo')::boolean,atualizado_em=now()
      where id=p_id and produto_id=p_produto_id returning * into v;
    if not found then raise exception 'Variação não encontrada.'; end if;
  end if;
  return to_jsonb(v);
end $$;
revoke all on function public.salvar_variacao(integer,uuid,jsonb) from public, anon, authenticated;
grant execute on function public.salvar_variacao(integer,uuid,jsonb) to service_role;


commit;
