# Atualização de segurança — 10/11/2026

O alerta de nível alto do npm audit foi identificado na dependência Nodemailer 7.0.13.

Foi feita uma atualização direcionada para nodemailer 10.5.0, com versão exata no package.json e no package-lock.json. O pacote @types/nodemailer foi removido, porque a nova versão do Nodemailer inclui os próprios tipos TypeScript. Nenhuma outra dependência foi alterada. Nenhum banco ou serviço remoto de aplicação foi acessado.

Validação local: npm audit passou com zero vulnerabilidades reportadas na consulta de 10/11/2026; os 23 testes do projeto e o build passaram. Um teste SMTP local separado confirmou a aceitação de avisos para cliente e loja com texto, HTML e Reply-To, sem enviar e-mails externos. Os dois avisos React de lint já documentados continuam independentes desta correção.

No Codespaces já atualizado para a entrega anterior, aplique apenas:

```bash
npm install --save-exact nodemailer@10.5.0 --ignore-scripts &&
npm uninstall --save-dev @types/nodemailer --ignore-scripts &&
npm audit &&
npm test &&
npm run build
```

Não use npm audit fix --force. Esta atualização não executa migrations nem muda credenciais. O ZIP v2 é a cópia completa com essa correção incorporada; não é necessário extraí-lo novamente se os comandos acima já foram executados.

Referência oficial: https://github.com/nodemailer/nodemailer/blob/master/CHANGELOG.md
