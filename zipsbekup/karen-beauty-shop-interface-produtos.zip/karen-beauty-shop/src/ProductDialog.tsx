import { useEffect, useRef, type ReactNode } from 'react'

export default function ProductDialog({ children, onClose }: { children: ReactNode; onClose: () => void }) {
  const ref = useRef<HTMLDialogElement>(null)
  useEffect(() => {
    const dialog = ref.current!
    const previous = document.activeElement as HTMLElement | null
    const overflow = document.body.style.overflow
    dialog.showModal()
    document.body.style.overflow = 'hidden'
    return () => { dialog.close(); document.body.style.overflow = overflow; previous?.focus() }
  }, [])
  return <dialog ref={ref} className="product-editor" aria-labelledby="product-editor-title" onCancel={e => { e.preventDefault(); onClose() }}>
    <button type="button" className="editor-close" aria-label="Fechar edição" onClick={onClose}>×</button>
    {children}
  </dialog>
}
