import { useCallback, useEffect, useState } from 'react'

type Draft = { id?: string; atualizado_em?: string; tipo: string; nome: string; sku: string; estoque: number; preco: string | number; preco_promocional: string | number; imagem: string; ativo: boolean }
const novo = (): Draft => ({ tipo: 'cor', nome: '', sku: '', estoque: 0, preco: '', preco_promocional: '', imagem: '', ativo: true })

export default function VariationEditor({ produtoId, convertido, estoqueOriginal, onUpdate }: { produtoId: number; convertido: boolean; estoqueOriginal: number; onUpdate: (convertido: boolean) => Promise<void> }) {
  const [lista, setLista] = useState<Draft[]>([])
  const [draft, setDraft] = useState<Draft>(novo)
  const [mensagem, setMensagem] = useState('')
  const [ocupado, setOcupado] = useState(false)
  const [carregado, setCarregado] = useState(false)
  const [estoqueInicial, setEstoqueInicial] = useState(0)
  const total = lista.reduce((s, v) => s + Number(v.estoque), 0)
  const carregar = useCallback(async () => {
    const r = await fetch('/api/admin/produtos')
    const dados = await r.json()
    if (!r.ok) throw new Error(dados.erro || 'Não foi possível carregar as variações.')
    setCarregado(true)
    setLista((dados.produtos.find((p: { id: number }) => p.id === produtoId)?.produto_variacoes || []).map((v: Draft) => ({ ...v, sku: v.sku || '', imagem: v.imagem || '', preco: v.preco ?? '', preco_promocional: v.preco_promocional ?? '' })))
  }, [produtoId])
  useEffect(() => { void carregar().catch(e => setMensagem(e.message)) }, [carregar])
  async function executar(converter = false) {
    setOcupado(true); setMensagem('')
    try {
      const r = await fetch(`/api/admin/produtos/${produtoId}/${converter ? 'converter-variacoes' : 'variacoes'}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(converter ? {} : { ...draft, estoque: draft.id && draft.estoque === estoqueInicial ? undefined : draft.estoque }),
      })
      const dados = await r.json()
      if (!r.ok) throw new Error(dados.erro || 'Não foi possível salvar.')
      setDraft(novo()); await carregar(); await onUpdate(converter || convertido); setMensagem('Alteração salva.')
    } catch (e) { setMensagem(e instanceof Error ? e.message : 'Erro ao salvar.') } finally { setOcupado(false) }
  }
  return <div><fieldset className="variation-editor" disabled={ocupado || !carregado}>
    <legend>Variações do produto</legend>
    <p>{convertido ? 'O estoque geral é a soma das variações. Desative uma opção para ocultá-la da loja.' : 'Cadastre as opções e distribua o estoque atual. Depois converta o produto; o total deve ser preservado e não pode haver pedidos aguardando pagamento.'}</p>
    <div className="stock-summary"><strong>{convertido ? 'Estoque total das variações' : 'Distribuição para conversão'}: {total} unidades</strong>{!convertido && <><br />Estoque original: {estoqueOriginal} · Falta distribuir: {estoqueOriginal - total}<br /><small>A conversão só é liberada quando os totais forem iguais. O servidor confere o estoque atual e as reservas.</small></>}</div>
    {!carregado && <p>Carregando variações...</p>}
    <ul className="variation-list">{lista.map(v => <li key={v.id}>{v.imagem && <img src={v.imagem} alt={v.nome} />}<div><strong>{v.nome}</strong><br /><small>{v.tipo} · SKU: {v.sku || '—'} · {v.estoque} unidades · {v.ativo ? 'Ativa' : 'Inativa'}</small></div><button type="button" onClick={() => { setDraft({ ...v }); setEstoqueInicial(v.estoque) }}>Editar / {v.ativo ? 'desativar' : 'ativar'}</button></li>)}</ul>
    {lista.length === 0 && carregado && <p>Nenhuma variação cadastrada. Comece adicionando uma opção abaixo.</p>}
    <h3>{draft.id ? `Editar ${draft.nome}` : 'Nova variação'}</h3>
    <div className="variation-fields">
      <label>Tipo<select value={draft.tipo} onChange={e => setDraft({ ...draft, tipo: e.target.value })}>{['cor','tamanho','fragrancia','acabamento','kit','outro'].map(t => <option key={t}>{t}</option>)}</select></label>
      <label>Nome<input value={draft.nome} maxLength={120} onChange={e => setDraft({ ...draft, nome: e.target.value })} /></label>
      <label>SKU<input value={draft.sku} onChange={e => setDraft({ ...draft, sku: e.target.value })} /></label>
      <label>Estoque<input type="number" min="0" step="1" value={draft.estoque} onChange={e => setDraft({ ...draft, estoque: Number(e.target.value) })} /></label>
      <label>Preço (vazio usa o produto)<input type="number" min="0" step="0.01" value={draft.preco} onChange={e => setDraft({ ...draft, preco: e.target.value })} /></label>
      <label>Preço promocional<input type="number" min="0" step="0.01" value={draft.preco_promocional} onChange={e => setDraft({ ...draft, preco_promocional: e.target.value })} /></label>
      <label>URL da imagem (HTTPS)<input type="url" value={draft.imagem} onChange={e => setDraft({ ...draft, imagem: e.target.value })} /></label>
      <label className="variation-active"><input type="checkbox" checked={draft.ativo} onChange={e => setDraft({ ...draft, ativo: e.target.checked })} /> Variação ativa</label>
    </div>
    <p><button type="button" disabled={!draft.nome.trim() || !Number.isSafeInteger(draft.estoque) || draft.estoque < 0} onClick={() => executar()}>{draft.id ? 'Salvar variação' : 'Adicionar variação'}</button> <button type="button" onClick={() => setDraft(novo())}>Limpar edição</button></p>
    {!convertido && <button type="button" disabled={!lista.length || total !== estoqueOriginal || lista.some(v => !v.ativo) || !!draft.id || !!draft.nome.trim()} onClick={() => executar(true)}>Converter preservando estoque total</button>}
    </fieldset>
    <p role="status" aria-live="polite">{mensagem}</p>
    <button type="button" disabled={ocupado} onClick={() => { setDraft(novo()); void carregar().then(() => onUpdate(convertido)).catch(e => setMensagem(e.message)) }}>Atualizar variações e estoque</button>
  </div>
}
