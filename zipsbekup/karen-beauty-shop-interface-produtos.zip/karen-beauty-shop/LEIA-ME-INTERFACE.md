# Karen Beauty Shop — interface de produtos

Entrega de 11/11/2026.

## Base preservada
Usada a cópia local da entrega corrigida v2, de 10/11/2026. A consulta ao GitHub j0aozin40/karen-beauty-shop encontrou somente o commit inicial ea6b24d; por isso essa versão antiga do GitHub não substituiu a entrega corrigida. Não houve acesso ao sistema de arquivos do Codespaces: alterações não salvas nele precisam ser comparadas antes da instalação. A pasta anterior permaneceu intacta.

Nenhum banco remoto foi alterado, nenhum pedido ou pagamento real foi criado e nada foi publicado ou enviado ao GitHub. As quantidades de registros do banco real não foram recontadas nesta tarefa.

## Entregue
- Janela central de edição com abas Geral, Fotos, Variações, Preços e Status, layout para computador e celular, foco contido no modal, Escape e navegação das abas por teclado.
- Nome, categoria e descrição; foto principal com envio/remoção; preços, custos e cálculo de margem; ativação/desativação do produto.
- Criação e edição de variações com tipo, nome, SKU, estoque individual, preço opcional, promoção, foto por URL HTTPS e ativação/desativação. O preço vazio herda o preço do produto.
- Resumo da soma do estoque e diferença a distribuir. Conversão habilitada somente com soma igual ao estoque original e todas as variações ativas. O backend continua validando a soma atual e os pedidos pendentes sob bloqueio transacional.
- Estoque de produtos convertidos calculado pelas variações. Edição de nome/preço/status não reenvia inventário. Ajustes de estoque geral usam comparação atômica com o saldo original; edições antigas de variações são rejeitadas pela função atualizada.
- Integração existente de seleção de variação, foto/preço individual, carrinho por produto + variação, checkout por ID de variação, reservas e Mercado Pago preservada e validada localmente.

Fotos e variações são salvas por suas próprias ações. “Salvar alterações” salva os dados gerais do produto. Para um produto novo, cadastre primeiro e reabra para adicionar fotos e variações.

## Antes de usar esta versão no ambiente real
1. Preserve a cópia atual do Codespaces, inclusive alterações não commitadas e arquivos de ambiente; compare com os arquivos desta entrega. Não substitua a pasta inteira nem o banco.
2. A migration adicional `supabase/migrations/202611110001_safe_variation_edit.sql` é necessária junto com esta versão. Ela atualiza apenas a função de salvar variação, sem alterar os registros existentes. NÃO foi aplicada remotamente. Revise e autorize sua aplicação pelo processo habitual, após backup, antes de disponibilizar a nova versão. Não reaplique as migrations antigas que já foram concluídas.
3. Atualize os arquivos de código mantendo seu `.env.local` e as credenciais existentes. O ZIP não contém credenciais reais, dependências instaladas ou build com configuração de teste.
4. Execute `npm ci`, `npm test` e `npm run build` com Node 24 ou superior e a configuração real do ambiente. Reinicie o servidor e publique somente após autorização.
5. Faça uma conferência autorizada em ambiente de teste com sessão administrativa, envio de fotos no Storage e credenciais de teste do Mercado Pago. A validação desta entrega não confirma as permissões/configurações atuais dos serviços reais.

## Validação realizada
- 25 testes automatizados aprovados: API, pagamento e PostgreSQL isolado em memória; inclui migrations, preservação de registros legados, soma da conversão, reservas, pagamento idempotente e conflitos de edição.
- TypeScript e build de produção aprovados.
- 0 vulnerabilidades na auditoria da instalação das dependências.
- Conferência automatizada em navegador Edge com dados fictícios: cinco abas, layout de computador/celular, salvar status de variação e dados gerais sem reenviar estoque.
- Fluxo de compra simulado no navegador: variação obrigatória, opção no carrinho e ID correto no checkout; nenhuma chamada a pagamento real.
- Lint sem erros; dois avisos sobre efeitos React já presentes nas rotinas de carregamento.

## Arquivos principais alterados/adicionados
`src/Admin.tsx`, `src/Admin.css`, `src/ProductDialog.tsx`, `src/VariationEditor.tsx`, `server/index.ts`, `supabase/migrations/202611110001_safe_variation_edit.sql`, `tests/api.test.ts`, `tests/stock.test.mjs`.

As migrations antigas e os fluxos de pagamento existentes foram preservados. Arquivos legados de backup continuam no pacote; arquivos `.bak` não são migrations a executar. `MANIFESTO-SHA256.txt` foi regenerado para esta entrega.
