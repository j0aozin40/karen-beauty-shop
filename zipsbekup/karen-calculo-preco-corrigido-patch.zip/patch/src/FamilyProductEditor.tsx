import { useEffect, useRef, useState } from 'react'
import ProductDialog from './ProductDialog'
import { variationTypes } from './variationTypes'
import { calcularPreco, precificacaoValida, type ProductCosts } from './pricing'

export type FamilyOption = { id?: string; atualizado_em?: string; tipo: string; nome: string; sku?: string | null; estoque: number; preco?: number | null; preco_promocional?: number | null; imagem?: string | null; ativo: boolean }
export type FamilyProduct = { id: number; nome: string; categoria: string; descricao?: string; estoque: number; preco: number; imagem?: string | null; ativo: boolean; atualizado_em?: string; controla_variacoes?: boolean; produto_variacoes?: FamilyOption[] } & Partial<Record<keyof ProductCosts, number | null>>
type Draft = Omit<FamilyOption, 'estoque' | 'preco' | 'preco_promocional' | 'imagem' | 'sku'> & { key: string; estoque: string | number; preco: string | number; preco_promocional: string | number; imagem: string; sku: string; file?: File; preview?: string }
const nova = (): Draft => ({ key: crypto.randomUUID(), tipo: 'cor', nome: '', sku: '', estoque: 0, preco: '', preco_promocional: '', imagem: '', ativo: true })
const moeda = (v: number | string) => Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

export default function FamilyProductEditor({ produto, categorias, onClose, onSaved }: { produto: FamilyProduct; categorias: { id: string; nome: string }[]; onClose: () => void; onSaved: () => Promise<void> }) {
  const [nome, setNome] = useState(produto.nome)
  const [categoria, setCategoria] = useState(produto.categoria)
  const [descricao, setDescricao] = useState(produto.descricao || '')
  const [custos, setCustos] = useState<ProductCosts>(() => ({ custo_aquisicao: Number(produto.custo_aquisicao || 0), custo_adicional: Number(produto.custo_adicional || 0), taxa_mp_percentual: Number(produto.taxa_mp_percentual || 0), taxas_adicionais_percentual: Number(produto.taxas_adicionais_percentual || 0), margem_desejada_percentual: Number(produto.margem_desejada_percentual ?? 30) }))
  const [opcoes, setOpcoes] = useState<Draft[]>(() => {
    if (produto.produto_variacoes?.length) return produto.produto_variacoes.map(v => ({ ...v, key: v.id!, sku: v.sku || '', preco: v.preco ?? produto.preco, preco_promocional: v.preco_promocional ?? '', imagem: v.imagem || produto.imagem || '', ativo: produto.ativo && v.ativo }))
    if (produto.id) return [{ ...nova(), tipo: 'outro', nome: 'Única', estoque: produto.estoque, preco: produto.preco, imagem: produto.imagem || '', ativo: produto.ativo }]
    return [nova()]
  })
  const [aberta, setAberta] = useState<string | null>(null)
  const [excluir, setExcluir] = useState<{ id: string; atualizado_em?: string }[]>([])
  const [busy, setBusy] = useState(false)
  const [erro, setErro] = useState('')
  const [dirty, setDirty] = useState(false)
  const previews = useRef(new Set<string>())
  const total = opcoes.reduce((s, v) => s + (Number(v.estoque) || 0), 0)
  const taxasSomadas = custos.taxa_mp_percentual + custos.taxas_adicionais_percentual
  useEffect(() => { const urls = previews.current; return () => { for (const url of urls) URL.revokeObjectURL(url) } }, [])

  function mudar(key: string, dados: Partial<Draft>) { setDirty(true); setErro(''); setOpcoes(lista => lista.map(v => v.key === key ? { ...v, ...dados } : v)) }
  function mudarCusto(campo: keyof ProductCosts, valor: string) { setDirty(true); setErro(''); setCustos(atual => ({ ...atual, [campo]: valor === '' ? 0 : Number(valor) })) }
  function mudarPercentual(campo: 'taxa_mp_percentual' | 'taxas_adicionais_percentual' | 'margem_desejada_percentual', valor: string) {
    const numero = valor === '' ? 0 : Number(valor)
    if (!Number.isFinite(numero) || numero < 0) {
      setErro('Informe um percentual positivo válido.')
      return
    }
    mudarCusto(campo, valor)
  }
  function fechar() { if (!busy && (!dirty || window.confirm('Descartar as alterações que ainda não foram salvas?'))) onClose() }
  function remover(v: Draft) {
    if (opcoes.length === 1) return
    if (v.id && produto.controla_variacoes && Number(v.estoque) > 0) { setErro('Esta opção possui estoque. Desative-a para preservar as quantidades.'); return }
    if (v.id) setExcluir(lista => [...lista, { id: v.id!, atualizado_em: v.atualizado_em }])
    setOpcoes(lista => lista.filter(x => x.key !== v.key)); setDirty(true)
  }
  function escolherFoto(v: Draft, file?: File) {
    if (!file) return
    if (!['image/jpeg','image/png','image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) { setErro('Selecione uma foto JPG, PNG ou WebP de até 5 MB.'); return }
    const preview = URL.createObjectURL(file); previews.current.add(preview); mudar(v.key, { file, preview })
  }

  async function salvar() {
    if (busy) return
    setErro('')
    if (!nome.trim() || nome.trim().length > 160 || !categoria.trim()) { setErro('Informe o nome do produto e selecione uma categoria.'); return }
    for (const v of opcoes) {
      const preco = Number(v.preco), estoque = Number(v.estoque), promocao = v.preco_promocional === '' ? null : Number(v.preco_promocional)
      let fotoValida = true
      if (v.imagem && !v.file) { try { const url = new URL(v.imagem); fotoValida = url.protocol === 'https:' && !url.username && !url.password } catch { fotoValida = false } }
      if (!v.nome.trim() || v.nome.length > 120 || !variationTypes[v.tipo] || String(v.preco).trim() === '' || !Number.isFinite(preco) || preco < 0 ||
        String(v.estoque).trim() === '' || !Number.isSafeInteger(estoque) || estoque < 0 ||
        (promocao !== null && (!Number.isFinite(promocao) || promocao < 0 || promocao > preco)) || !fotoValida) {
        setAberta(v.key); setErro('Confira nome, preço, estoque, promoção e URL HTTPS da opção destacada.'); return
      }
    }
    if (!precificacaoValida(custos)) { setErro('As porcentagens devem ser de 0 a 99,99%, e a soma das taxas e da margem precisa ficar abaixo de 100%.'); return }
    let confirmarAjuste = false
    if (produto.id && !produto.controla_variacoes && total !== produto.estoque) {
      confirmarAjuste = window.confirm(`O estoque físico passará de ${produto.estoque} para ${total} unidades. Confirme somente se as quantidades das opções correspondem ao estoque real. Confirmar ajuste?`)
      if (!confirmarAjuste) return
    }
    setBusy(true)
    let gravou = false
    try {
      const prontas: Draft[] = []
      for (const v of opcoes) {
        if (!v.file) { prontas.push(v); continue }
        const r = await fetch('/api/admin/variacoes/foto', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': v.file.type }, body: v.file })
        const data = await r.json()
        if (!r.ok) throw new Error(data.erro || 'Não foi possível enviar uma foto.')
        const atual = { ...v, imagem: data.imagem, file: undefined, preview: undefined }
        prontas.push(atual); setOpcoes(lista => lista.map(x => x.key === v.key ? atual : x))
      }
      const r = await fetch('/api/admin/grupos-variacoes', {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: produto.id || null, atualizado_em: produto.atualizado_em, estoque_original: produto.estoque,
          nome, categoria, descricao, ...custos, confirmar_ajuste_estoque: confirmarAjuste, excluir,
          variacoes: prontas.map(v => ({ id: v.id || null, atualizado_em: v.atualizado_em, tipo: v.tipo, nome: v.nome.trim(), sku: v.sku,
            estoque: Number(v.estoque), preco: Number(v.preco), preco_promocional: v.preco_promocional === '' ? null : Number(v.preco_promocional), imagem: v.imagem || null, ativo: v.ativo })),
        }),
      })
      const data = await r.json()
      if (!r.ok) throw new Error(data.erro || 'Não foi possível salvar as alterações.')
      gravou = true; setDirty(false); await onSaved()
    } catch (e) { setErro((gravou ? 'O cadastro foi salvo, mas a lista precisa ser atualizada. ' : '') + (e instanceof Error ? e.message : 'Erro ao salvar.')) }
    finally { setBusy(false) }
  }

  return <ProductDialog onClose={fechar}><form className="family-editor-form" noValidate onSubmit={e => { e.preventDefault(); void salvar() }}>
    <header className="family-editor-header"><small>KAREN BEAUTY SHOP</small><h2 id="product-editor-title">{produto.id ? 'Editar produto' : 'Cadastrar produto'}</h2><div className="family-single-tab" role="tablist" aria-label="Cadastro"><span role="tab" tabIndex={0} aria-selected="true" aria-controls="family-general" id="family-tab">Geral</span></div></header>
    <section id="family-general" role="tabpanel" aria-labelledby="family-tab" className="family-editor-scroll">
      <fieldset disabled={busy} className="family-shared-fields"><div className="family-name-category"><label>Nome do produto<input required maxLength={160} value={nome} onChange={e => { setNome(e.target.value); setDirty(true) }} /></label><label>Categoria<select required aria-label="Categoria do produto" value={categoria} onChange={e => { setCategoria(e.target.value); setDirty(true) }}><option value="">Selecione…</option>{categorias.map(c => <option value={c.nome} key={c.id}>{c.nome}</option>)}</select></label></div><label>Descrição<textarea maxLength={10000} rows={2} value={descricao} onChange={e => { setDescricao(e.target.value); setDirty(true) }} /></label></fieldset>
      <details className="family-pricing"><summary>Custos e cálculo do preço</summary><p>Preencha os custos uma vez para o produto. A sugestão é calculada separadamente para o preço de cada variação.</p><div className="family-pricing-grid"><label>Custo de aquisição (R$)<input aria-label="Custo de aquisição" type="number" min="0" step="0.01" value={custos.custo_aquisicao} onChange={e => mudarCusto('custo_aquisicao', e.target.value)} /></label><label>Custos adicionais por unidade (R$)<input aria-label="Custos adicionais por unidade" type="number" min="0" step="0.01" value={custos.custo_adicional} onChange={e => mudarCusto('custo_adicional', e.target.value)} /></label><label>Taxa Mercado Pago (%)<input aria-label="Taxa Mercado Pago" type="number" min="0" step="0.01" value={custos.taxa_mp_percentual} onChange={e => mudarPercentual('taxa_mp_percentual', e.target.value)} /></label><label>Taxas adicionais (%)<input aria-label="Taxas adicionais" type="number" min="0" step="0.01" value={custos.taxas_adicionais_percentual} onChange={e => mudarPercentual('taxas_adicionais_percentual', e.target.value)} /></label><label>Lucro desejado sobre custo (%)<input aria-label="Lucro desejado sobre custo" type="number" min="0" step="0.01" value={custos.margem_desejada_percentual} onChange={e => mudarPercentual('margem_desejada_percentual', e.target.value)} /></label></div><small>O percentual de lucro é aplicado sobre os custos, sem teto fixo. As taxas são acrescentadas depois para calcular o preço de venda.</small></details>
      <div className="family-options-heading"><h3>Variações</h3><button type="button" className="admin-action secondary" disabled={busy || opcoes.length >= 50} onClick={() => { const v = nova(); setOpcoes(lista => [...lista, v]); setAberta(v.key); setDirty(true) }}>＋ Adicionar variação</button></div>
      {!produto.controla_variacoes && produto.id > 0 && <p className="family-legacy-note">Este cadastro ainda usa estoque geral. Ao salvar, as opções passarão a ter controle individual, após conferir as quantidades e os pedidos pendentes.</p>}
      <div className="family-options-list">{opcoes.map((v, i) => {
        const expandida = aberta === v.key || (aberta === null && i === 0)
        const meta = variationTypes[v.tipo] || variationTypes.outro
        const imagem = v.preview || v.imagem
        return <article className={`family-option ${expandida ? 'expanded' : ''} ${v.ativo ? '' : 'inactive'}`} key={v.key}>
          <header className="family-option-header"><button type="button" className="family-option-summary" aria-expanded={expandida} aria-controls={`option-${v.key}`} disabled={busy} onClick={() => setAberta(expandida ? 'nenhuma' : v.key)}>{imagem ? <img src={imagem} alt="" /> : <span className="family-photo-placeholder" aria-hidden="true">◇</span>}<span><strong>{v.nome || 'Nova variação'}</strong><small>{Number(v.estoque) || 0} unidades · {moeda(v.preco_promocional === '' ? v.preco : v.preco_promocional)}</small></span><span className="family-chevron" aria-hidden="true">{expandida ? '⌃' : '⌄'}</span></button><button type="button" className="family-option-switch" role="switch" aria-checked={v.ativo} aria-label={`Variação ${v.nome || i + 1} ativa`} disabled={busy} onClick={() => mudar(v.key, { ativo: !v.ativo })}><span className="family-switch-track"><span /></span>{v.ativo ? 'Ativa' : 'Inativa'}</button></header>
          <fieldset disabled={busy} id={`option-${v.key}`} hidden={!expandida} className="family-option-fields"><div className="family-fields-grid">
            <label>Tipo<select aria-label={`Tipo da variação ${i + 1}`} value={v.tipo} onChange={e => mudar(v.key, { tipo: e.target.value })}>{Object.entries(variationTypes).map(([key, value]) => <option key={key} value={key}>{value.label}</option>)}</select></label>
            <label>{meta.field}<input aria-label={`${meta.field} ${i + 1}`} required maxLength={120} placeholder={meta.placeholder} value={v.nome} onChange={e => mudar(v.key, { nome: e.target.value })} /></label>
            <label>SKU<input aria-label={`SKU ${i + 1}`} maxLength={100} value={v.sku} placeholder="Código interno" onChange={e => mudar(v.key, { sku: e.target.value })} /></label>
            <label>Preço<input aria-label={`Preço ${i + 1}`} required type="number" min="0" step="0.01" value={v.preco} onChange={e => mudar(v.key, { preco: e.target.value })} />{(() => { const calculo = calcularPreco(Number(v.preco) || 0, custos); return <small className="family-price-calc">{calculo ? <>Sugerido: {moeda(calculo.sugerido)} · Lucro estimado: {moeda(calculo.lucro)} <button type="button" disabled={busy} onClick={() => mudar(v.key, { preco: calculo.sugerido })}>Aplicar</button></> : taxasSomadas >= 100 ? 'As taxas somam 100% ou mais. Reduza as taxas para calcular o preço.' : 'Revise os custos e percentuais para calcular o preço.'}</small> })()}</label>
            <label>Estoque<input aria-label={`Estoque ${i + 1}`} required type="number" min="0" step="1" value={v.estoque} onChange={e => mudar(v.key, { estoque: e.target.value })} /></label>
            <label>Preço promocional <small>(opcional)</small><input aria-label={`Preço promocional ${i + 1}`} type="number" min="0" step="0.01" value={v.preco_promocional} onChange={e => mudar(v.key, { preco_promocional: e.target.value })} /></label>
            <label className="family-photo-url">Foto por URL<input aria-label={`Foto por URL ${i + 1}`} type="url" maxLength={2048} placeholder="https://…" value={v.imagem} onChange={e => mudar(v.key, { imagem: e.target.value, file: undefined, preview: undefined })} /></label>
            <label className="family-upload">↑ Enviar imagem<input type="file" accept="image/jpeg,image/png,image/webp" aria-label={`Enviar imagem ${i + 1}`} onChange={e => escolherFoto(v, e.target.files?.[0])} /></label>
          </div><div className="family-option-bottom"><small>{v.file ? `Imagem selecionada: ${v.file.name}` : 'Foto por URL ou arquivo · JPG, PNG ou WebP até 5 MB'}</small><button type="button" className="family-remove" disabled={opcoes.length === 1 || (Boolean(v.id) && Boolean(produto.controla_variacoes) && Number(v.estoque) > 0)} title="Opções com estoque ou histórico devem ser desativadas para preservar os registros." onClick={() => remover(v)}>Remover opção</button></div></fieldset>
        </article>
      })}</div>
      <p className="family-total">{opcoes.length} {opcoes.length === 1 ? 'variação' : 'variações'} · {total} unidades no total{dirty && <span> · Alterações ainda não salvas</span>}</p>
      {erro && <p role="alert" className="variation-feedback error">{erro}</p>}
    </section>
    <footer className="family-editor-footer"><button type="button" className="admin-action secondary" disabled={busy} onClick={fechar}>Cancelar</button><button type="submit" className="admin-action primary" disabled={busy}>{busy ? 'Salvando…' : 'Salvar alterações'}</button></footer>
  </form></ProductDialog>
}
