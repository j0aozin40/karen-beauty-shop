import type { Product } from '../src/products.ts'

// O agrupamento é interno. Cada opção publicada possui uma identidade de compra própria.
export function vitrineVariacoes(grupos: Product[]): Product[] {
  const opcoes = new Map<string, Product>()
  for (const grupo of grupos) {
    if (!grupo.controla_variacoes) {
      opcoes.set(`${grupo.id}:`, { ...grupo, variacoes: undefined, variacao_principal_id: undefined })
      continue
    }
    for (const opcao of grupo.variacoes || []) {
      const item: Product = {
        ...grupo, name: `${grupo.name} — ${opcao.nome}`, familyName: grupo.name,
        variationId: opcao.id, variationName: opcao.nome,
        price: Number(opcao.price), stock: Number(opcao.stock),
        imagem: opcao.imagem || grupo.imagem,
        variacoes: undefined, variacao_principal_id: undefined,
      }
      opcoes.set(`${grupo.id}:${opcao.id}`, item)
    }
  }
  return [...opcoes.values()]
}
