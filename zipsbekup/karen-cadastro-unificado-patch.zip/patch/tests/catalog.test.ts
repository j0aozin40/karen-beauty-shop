import { test } from 'node:test'
import assert from 'node:assert/strict'
import { vitrineVariacoes } from '../server/catalog.ts'
import type { Product } from '../src/products.ts'

test('vitrine publica cada opção uma única vez com preço, foto e estoque próprios', () => {
  const grupo: Product = { id: 1, name: 'Henna', category: 'Sobrancelhas', price: 40, stock: 8, description: '', emoji: '🤎', imagem: 'https://example.test/base.jpg', controla_variacoes: true, variacao_principal_id: 'rosa', variacoes: [
    { id: 'rosa', tipo: 'cor', nome: 'Rosa', price: 29.9, stock: 4, imagem: 'https://example.test/rosa.jpg' },
    { id: 'preto', tipo: 'cor', nome: 'Preto', price: 30, stock: 4 },
  ] }
  const itens = vitrineVariacoes([grupo, grupo])
  assert.equal(itens.length, 2)
  assert.equal(itens[0].name, 'Henna — Rosa')
  assert.equal(itens[0].price, 29.9)
  assert.equal(itens[0].stock, 4)
  assert.equal(itens[0].variationId, 'rosa')
  assert.equal(itens[0].imagem, 'https://example.test/rosa.jpg')
  assert.equal(itens[1].imagem, grupo.imagem)
  assert.equal(itens[0].variacao_principal_id, undefined)
  assert.equal(itens[0].variacoes, undefined)
  assert.equal(vitrineVariacoes([{ ...grupo, variacoes: [] }]).length, 0)
  const legado = vitrineVariacoes([{ ...grupo, controla_variacoes: false }])
  assert.equal(legado.length, 1)
  assert.equal(legado[0].id, 1)
  assert.equal(legado[0].variationId, undefined)
})
