# Karen Beauty Shop — cadastro unificado e vitrine por variação

## Entregue
- A edição de produtos tem uma única aba Geral.
- Nome do produto/linha, categoria e descrição são preenchidos uma vez.
- Variações ficam em cartões expansíveis com tipo, nome, SKU, preço, estoque, promoção opcional, foto por URL ou arquivo e ativação/desativação.
- Há um único Salvar alterações. Todas as mudanças de dados são confirmadas em uma transação; ativar/desativar entra nesse salvamento.
- Não há cadastro ou seletor de opção principal na nova tela. A função anterior é removida do agrupamento quando ele é salvo pelo novo editor.
- Cada opção ativa aparece como cartão individual no catálogo, com nome composto, imagem, preço e estoque próprios. O agrupamento interno não ganha outro cartão.
- Cada cartão abre a opção específica por `/produto/ID?variacao=UUID`. Carrinho e checkout continuam usando produto_id + variacao_id.
- Produtos relacionados priorizam outras opções do mesmo agrupamento, sem repetir a opção em exibição. O restante da vitrine mostra as opções individualmente na rolagem.
- A imagem fica contida no cartão e não cobre o título ou os botões.
- A lista administrativa mostra a faixa de preços das opções, em vez de um preço geral duplicado.
- A seção de Pedidos de teste continua removida do painel.

## Preservação dos cadastros existentes
A instalação e a migration NÃO fazem conversão automática em massa. Cadastros já convertidos continuam com os mesmos IDs e estoques; as opções ativas passam a aparecer individualmente ao atualizar a API.

Cadastros antigos sem opções continuam funcionando como uma oferta única compatível. Ao editar, recebem uma opção inicial preenchida com seu preço, foto e estoque atuais. Ao salvar, o backend cria as opções reais e converte o controle, conferindo pedidos e reservas pendentes. Os rascunhos existentes também são carregados na mesma tela.

O estoque do agrupamento é a soma de TODAS as opções, inclusive inativas. Desativar não apaga estoque. Se a soma informada para um cadastro antigo divergir do estoque original, o editor pede confirmação explícita do ajuste físico. Isso não deve ser confirmado apenas para ultrapassar um bloqueio.

Reservas, pedidos pendentes e edições concorrentes podem bloquear o salvamento. Quando um pagamento altera o estoque enquanto a edição está aberta, o salvamento antigo é rejeitado integralmente. As quantidades não são repostas automaticamente.

Opções com estoque convertido, pedidos ou histórico de reservas continuam protegidas contra exclusão. Prefira desativar. Remover opção só será efetivado ao salvar, se o banco permitir.

Custos e taxas anteriormente salvos são preservados no banco. Eles não aparecem como outro formulário de preenchimento na nova tela simplificada. Pedidos existentes e snapshots de itens não são reescritos.

## Instalar
1. Preserve o ambiente atual e pare os dois servidores com Ctrl+C nos respectivos terminais.
2. Envie `karen-cadastro-unificado-patch.zip` para `/workspaces/karen-beauty-shop`.
3. No Codespaces, execute:

```bash
PASTA_PATCH="$(mktemp -d /workspaces/karen-unificado-XXXXXX)"
unzip -n /workspaces/karen-beauty-shop/karen-cadastro-unificado-patch.zip -d "$PASTA_PATCH" &&
node "$PASTA_PATCH/aplicar-cadastro-unificado.mjs" /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
```

O instalador verifica integridade, aceita as versões já entregues nesta conversa, cria backup dos arquivos substituídos e para se encontrar alterações locais desconhecidas. `.env`, credenciais e dados do banco são preservados. Ele não aplica SQL.

## Atualização de banco — aplicação ainda pendente
Arquivo: `supabase/migrations/202611110004_unified_variation_editor.sql`.

Esta migration prepara a função de salvamento único e garante a existência da função de exclusão segura. Não converte, exclui ou redistribui produtos ao ser executada. A função de salvar só altera um cadastro quando o administrador confirma Salvar alterações.

A estrutura de variações, reservas e a migration de opção principal já confirmadas nesta conversa são pré-requisitos. Não reaplique migrations antigas nem operações de limpeza de pedidos. A nova migration NÃO foi aplicada remotamente nesta tarefa; é necessária autorização do usuário antes da aplicação no Supabase.

Após a aplicação autorizada, confirme:

```sql
select to_regprocedure(
  'public.salvar_grupo_variacoes(integer,jsonb,jsonb,jsonb,boolean)'
) is not null as cadastro_unificado_instalado;
```

O resultado esperado é true. Execute o SQL completo de begin até commit no SQL Editor, como administrador do banco. Envie qualquer erro sem remover as proteções para forçar a operação.

## Validar e reiniciar

```bash
cd /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
npm test && npm run build
```

Terminal da API:

```bash
cd /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
npm run server
```

Outro terminal, site:

```bash
cd /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
npm run dev -- --host 0.0.0.0 --port 5174 --strictPort
```

Mantenha o túnel do PowerShell do Windows aberto. Atualize o navegador com Ctrl+Shift+R e abra `/admin`.

## Fotos e funcionamento do salvamento
As imagens por URL precisam ser HTTPS. Arquivos JPG, PNG e WebP até 5 MB podem ser selecionados em cada opção. O envio do arquivo acontece quando se salva o cadastro. A gravação dos dados é transacional; um arquivo já enviado pode permanecer no Storage se o banco rejeitar o salvamento. Arquivos antigos não são apagados automaticamente, preservando suas referências.

Cada opção tem uma imagem própria. A foto antiga do agrupamento é preenchida nas opções que a herdavam; depois do salvamento não fica uma foto geral oculta prevalecendo sobre uma foto removida de uma opção.

O agrupamento aceita até 50 opções por edição. Uma combinação de atributos, como Rosa/M, precisa ser cadastrada como uma opção vendável com seu próprio estoque. Não são geradas combinações automáticas.

## Verificações realizadas
48 testes aprovados: API, permissões, cadastro atômico, rollback por erro em uma opção, cadastro com IDs importados e sequência antiga atrasada, estoque em pagamento, concorrência, ativação/desativação, exclusão protegida, conversão de legado, confirmação de ajuste físico, fotos e compatibilidade com reservas/Mercado Pago. TypeScript e build aprovados.

Conferência em navegador com dados fictícios: aba Geral única, um botão Salvar, tipos adaptáveis, foto por arquivo, celular, criação de produto com opção já no primeiro salvamento, cartões separados e duas opções do mesmo agrupamento no carrinho e no checkout com IDs distintos. Nenhum pedido ou pagamento real criado.

Nenhum banco remoto alterado, nenhuma publicação ou envio ao GitHub realizado. Esta entrega substitui os guias anteriores sobre abas e opção principal; arquivos antigos de referência foram preservados no ZIP completo.
