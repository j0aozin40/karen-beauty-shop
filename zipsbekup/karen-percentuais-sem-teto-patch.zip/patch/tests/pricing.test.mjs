import { test } from 'node:test'
import assert from 'node:assert/strict'
import { calcularPreco, precificacaoValida } from '../src/pricing.ts'

test('cálculo inclui taxas, custos e margem líquida desejada', () => {
  const custos = { custo_aquisicao: 10, custo_adicional: 2, taxa_mp_percentual: 10, taxas_adicionais_percentual: 5, margem_desejada_percentual: 25 }
  const resultado = calcularPreco(20, custos)
  assert.equal(resultado.sugerido, 20)
  assert.equal(resultado.lucro, 5)
  assert.equal(resultado.margemReal, 25)
})

test('não impõe teto nem limite na soma dos percentuais informados', () => {
  const base = { custo_aquisicao: 0, custo_adicional: 0, taxa_mp_percentual: 0, taxas_adicionais_percentual: 0, margem_desejada_percentual: 0 }
  assert.equal(precificacaoValida({ ...base, taxa_mp_percentual: 100 }), true)
  assert.equal(precificacaoValida({ ...base, taxa_mp_percentual: 9999, taxas_adicionais_percentual: 25, margem_desejada_percentual: 250 }), true)
  assert.equal(precificacaoValida({ ...base, taxa_mp_percentual: -1 }), false)
  assert.equal(calcularPreco(10, { ...base, taxa_mp_percentual: 100 }), null)
})
