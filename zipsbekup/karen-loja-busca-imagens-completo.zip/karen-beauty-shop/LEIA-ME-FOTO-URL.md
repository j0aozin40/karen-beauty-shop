# Foto principal por URL na aba Fotos

Adicionado o campo URL da foto principal e o botão Salvar foto por URL em Produtos → Editar → Fotos. O envio de arquivo e a prévia continuam nessa aba. O campo de URL foi retirado do formulário de opção principal na aba Geral.

A URL precisa ser HTTPS, sem usuário/senha no endereço. O servidor não baixa a imagem: salva o endereço da foto base no produto. As fotos específicas de variações continuam sendo configuradas na aba Variações e podem prevalecer quando essas opções estão selecionadas.

## Instalar
Envie karen-foto-url-patch.zip para /workspaces/karen-beauty-shop e execute:

```bash
PASTA_PATCH="$(mktemp -d /workspaces/karen-foto-url-XXXXXX)"
unzip -n /workspaces/karen-beauty-shop/karen-foto-url-patch.zip -d "$PASTA_PATCH" &&
node "$PASTA_PATCH/aplicar-foto-url.mjs" /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
```

Parte da atualização de opção principal já instalada. Faz backup dos arquivos substituídos, confere se correspondem à entrega anterior e preserva as configurações. Não toca no estoque ou no banco remoto durante a instalação. Não exige migration.

Reinicie a API e atualize o painel com Ctrl+Shift+R. Na aba Fotos, cole o endereço direto da imagem e clique em Salvar foto por URL. O salvamento é feito por essa ação; não é necessário salvar os dados gerais novamente.

35 testes aprovados e build concluído. A conferência no navegador validou o campo apenas em Fotos, salvamento, reabertura com a URL persistida, envio por arquivo mantido e estoque preservado. A instalação no Codespaces e o salvamento no banco real ainda precisam ser realizados pelo usuário.
