# Busca automática de imagens — entrega de 11/11/2026

## O que foi integrado

O editor unificado de produtos (`FamilyProductEditor`) oferece **Buscar imagem automaticamente** para produtos/variações já salvos, sem alterações pendentes e sem foto. Ao clicar, a busca valida os candidatos e publica automaticamente a URL vencedora. O cadastro é atualizado e o editor fecha. Não há execução em lote ou busca disparada apenas por abrir o editor.

Fluxo: painel → sessão administrativa Express → Edge Function privada → API de catálogo autorizado → validação do arquivo/origem/licença → RPC transacional → imagem da variação selecionada (ou produto legado sem variações). O navegador não recebe segredos de fornecedor ou do banco.

São exigidos:

- Nome do produto, tipo e nome da variação exatos, normalizados apenas em caixa, espaços e Unicode. SKU também deve ser exato quando o cadastro possui SKU. Não há correspondência aproximada ou publicação por mera semelhança de palavras.
- PNG/JPEG decodificável, MIME coerente, mínimo **800 pixels em cada dimensão**, até 5 MiB comprimidos, máximo 4 megapixels e 4096 pixels por lado. SVG, WebP, GIF e outros formatos são recusados neste fluxo automático. O envio manual continua funcionando como antes.
- Preferência pela proporção mais próxima de 1:1; empate resolvido pela maior área. Não corta nem amplia imagens.
- HTTPS, domínios exatos previamente autorizados, sem credenciais, portas alternativas, query string, fragmentos ou redirecionamentos. URLs temporárias com tokens não são aceitas. Verifica endereços DNS A/AAAA e recusa redes não públicas; use somente domínios de fornecedores/CDNs confiáveis controlados contratualmente, nunca domínios enviados por clientes. A checagem DNS não fixa a conexão ao IP consultado, portanto a lista de domínios confiáveis é uma fronteira de segurança necessária.
- Origem e página de evidência de licença acessíveis; licença previamente autorizada, uso comercial e hotlink expressamente permitidos no contrato do fornecedor. Licenças que exigem atribuição pública são recusadas, pois a vitrine atual não exibe créditos.
- Nova conferência e bloqueio das linhas no banco antes da publicação. Se foto, nome, SKU, variação ou versão do cadastro mudar durante a busca, não publica. **Qualquer foto existente é preservada**, inclusive fotos automáticas anteriores, uploads e URLs manuais.

As imagens são baixadas temporariamente na memória para validação. O banco armazena somente URL e metadados; nenhum arquivo binário é salvo em banco ou Storage. O histórico fica em `product_image_searches`, sem leitura pública. Tentativas sem publicação ficam como `searching` e expiram para fins de publicação após dois minutos. Há intervalo mínimo de 60 segundos entre buscas do mesmo produto, inclusive quando falham.

## Dependências externas e limites da validação

**Não foi configurado nem contatado um fornecedor real.** É necessário um catálogo/API autorizado que implemente o contrato abaixo, ou um adaptador específico para a API do fornecedor escolhido. Uma chave genérica de mecanismo de busca, isoladamente, não atende a esse contrato nem comprova licença comercial.

A verificação de correspondência se baseia na identidade do catálogo confiável; não há reconhecimento visual por IA. A disponibilidade das páginas de origem/licença não prova juridicamente seu conteúdo. O operador deve autorizar previamente o fornecedor, os domínios e os identificadores de licença com base no contrato real, incluindo permissão de uso comercial e hotlink. O fornecedor deve garantir a ligação correta entre metadados e arquivo. Não publique automaticamente a partir de resultados de busca sem essa garantia.

Uma URL externa pode deixar de funcionar ou trocar de conteúdo posteriormente. Esta versão valida no momento da busca/publicação e não executa monitoramento periódico. Não foi realizada implantação nem teste com serviços de produção.

## Configuração

No servidor da loja:

```dotenv
# Já existente; deve ser a origem pública exata da loja
PUBLIC_APP_URL=https://sua-loja.example.com
# Mesmo valor na Edge Function; gere um segredo aleatório com pelo menos 32 caracteres
IMAGE_SEARCH_SHARED_SECRET=
```

Na Edge Function (Supabase Secrets, nunca variáveis VITE):

```dotenv
IMAGE_SEARCH_SHARED_SECRET=
IMAGE_PROVIDER_URL=https://api.fornecedor.example.com/product-images/search
IMAGE_PROVIDER_TOKEN=
IMAGE_PROVIDER_HOSTS=api.fornecedor.example.com
IMAGE_HOSTS=cdn.fornecedor.example.com
IMAGE_SOURCE_HOSTS=www.fornecedor.example.com
IMAGE_LICENSES=contrato-fornecedor-v1
```

As listas são separadas por vírgula, com nomes de host exatos em minúsculas; não aceitam curingas. `SUPABASE_URL` e `SUPABASE_SERVICE_ROLE_KEY` são disponibilizados pelo ambiente Supabase da função. O servidor mantém sua configuração Supabase atual.

A Edge Function usa autenticação própria em `x-image-search-secret`. `verify_jwt=false` desliga a verificação JWT do gateway; **não remove a autenticação feita pelo handler**. O servidor exige sessão administrativa e origem correta antes de encaminhar a chamada. Não invoque a função diretamente pelo frontend. Referências oficiais: [autenticação de Edge Functions](https://supabase.com/docs/guides/functions/auth) e [segurança de funções de banco](https://supabase.com/docs/guides/database/functions).

## Contrato da API do fornecedor/adaptador

Requisição `POST IMAGE_PROVIDER_URL`, com `Authorization: Bearer IMAGE_PROVIDER_TOKEN`:

```json
{"nome":"Capinha Samsung A15","tipo":"cor","variacao":"Preta","sku":"A15-PRETA","limit":8}
```

Para produto legado sem variações: `tipo` e `variacao` são strings vazias e `sku` é `null`. A identidade é lida do banco, nunca do texto enviado pelo navegador. Resposta JSON máxima de 128 KiB, no formato:

```json
{
  "candidates": [{
    "nome": "Capinha Samsung A15",
    "tipo": "cor",
    "variacao": "Preta",
    "sku": "A15-PRETA",
    "url": "https://cdn.fornecedor.example.com/a15-preta.png",
    "source": "https://www.fornecedor.example.com/produtos/a15-preta",
    "license": "contrato-fornecedor-v1",
    "evidence": "https://www.fornecedor.example.com/licenca-revenda",
    "commercial": true,
    "hotlink": true,
    "attribution_required": false,
    "attribution": "Fornecedor autorizado"
  }]
}
```

Somente os primeiros oito candidatos são avaliados. Cada chamada externa tem limite de oito segundos, sem redirecionar tokens. A página de origem/evidência tem limite de 512 KiB. Não implemente o adaptador preenchendo `commercial`, `hotlink` ou identidade por suposição: esses campos precisam vir do catálogo e da autorização contratual.

## Implantação sem alterar o catálogo existente

1. Instale as dependências com `npm ci`. Faça backup normal da implantação e valide primeiro em homologação.
2. Confirme que a base já tem as migrations anteriores desta versão (incluindo variações e cadastro unificado). **Aplique somente** `supabase/migrations/202611110007_product_image_search.sql` nesta atualização, uma vez. Não reaplique migrations antigas nem execute scripts de importação/limpeza existentes no projeto.
3. A migration cria apenas uma tabela de auditoria, índice e duas RPCs. Habilita RLS, revoga acesso de `public`, `anon` e `authenticated` e concede acesso somente a `service_role`. Não atualiza produtos, variações, pedidos, estoque ou preços durante a instalação.
4. Configure os segredos e publique `supabase functions deploy search-product-images --project-ref SEU_PROJECT_REF`. A configuração por função e o arquivo `deno.json` acompanham o pacote; mantenha-os. Confirme `verify_jwt=false` e a autenticação própria do handler. As dependências PNG/JPEG e seus hashes estão fixados no lockfile Deno.
5. Configure `IMAGE_SEARCH_SHARED_SECRET` também no servidor e `PUBLIC_APP_URL`, gere a versão do frontend com `npm run build` e reinicie o servidor atualizado. Não copie credenciais para arquivos públicos.
6. Teste primeiro com produto de homologação sem foto. Cadastros novos ou com alterações pendentes devem ser salvos e reabertos antes da busca. Foto manual existente deve manter o botão bloqueado.

Ao clicar no botão em produção, uma publicação aprovada modifica intencionalmente somente a imagem do alvo e seu timestamp, além da auditoria. Instalar o código/migration por si só não dispara buscas nem publicações.

Para desativar, remova o segredo do servidor e/ou despublique a Edge Function; preserve auditoria e imagens existentes. Não há rotina de exclusão automática de histórico nesta entrega.

## Validação executada

- **68 testes aprovados** na suíte completa, incluindo interface em DOM simulado, sessão/origem administrativa, fluxo da Edge Function com APIs simuladas, proteção de fotos manuais, resolução, arquivos corrompidos/CRC, licença, URL, DNS, conflitos de cadastro, expiração e intervalo entre buscas.
- Testes PostgreSQL local com PGlite confirmam RLS/permissões e que a nova migration mantém exatamente o conteúdo anterior das tabelas de catálogo, variações e pedidos. Os 105 produtos e 12 pedidos usados neste teste são **dados sintéticos**, não uma cópia nem uma conferência dos dados reais informados pelo usuário.
- Verificação TypeScript e compilação Vite aprovadas. Lint sem erros, com quatro avisos já existentes nos componentes anteriores.
- Checagem Deno 2.5.6 da Edge Function e oito testes do handler executados também em Deno com sucesso.
- Auditoria de dependências na instalação: nenhuma vulnerabilidade reportada pelo npm naquele momento.

Reprodução: `npm test`, `npm run build`, `npm run lint`. Para Deno: `deno check --config supabase/functions/search-product-images/deno.json supabase/functions/search-product-images/index.ts` e `deno test --allow-read --config supabase/functions/search-product-images/deno.json tests/image-search.test.ts`.

O teste da interface verifica comportamento e mensagens em DOM simulado; não substitui homologação visual em navegadores reais. Não houve leitura nem alteração do banco de produção, e as contagens reais de 105 produtos e 12 pedidos não foram reconfirmadas nesta tarefa.
