# Foto principal e seleção de variação

## Correção
A imagem principal agora continua acessível pela miniatura Principal, abaixo da foto grande. A opção escolhida, o preço e o estoque permanecem selecionados ao trocar somente a foto. A miniatura da variação permite voltar à imagem dela.
O botão Limpar seleção remove a escolha e restaura a foto principal, o preço base e o estado inicial da compra, sem precisar recarregar a página. Selecionar outra variação mostra a foto da nova opção.

## Instalação no Codespaces
Envie `karen-galeria-produto-patch.zip` para `/workspaces/karen-beauty-shop` e execute:

```bash
PASTA_PATCH="$(mktemp -d /workspaces/karen-galeria-XXXXXX)"
unzip -n /workspaces/karen-beauty-shop/karen-galeria-produto-patch.zip -d "$PASTA_PATCH" &&
node "$PASTA_PATCH/aplicar-galeria.mjs" /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
```

Faz backup, confere se os arquivos são os da interface v2 e substitui somente os arquivos da galeria. Não toca no banco, no servidor, nas credenciais ou nas mudanças para remover a seção de pedidos de teste. O manifesto de integridade local é atualizado somente nas entradas dos arquivos desta correção.

Atualize a página da loja com Ctrl+Shift+R. Se o servidor Vite tiver sido parado, reinicie no terminal do Codespaces:

```bash
cd /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
npm run dev -- --host 0.0.0.0 --port 5174 --strictPort
```

Mantenha a API e o túnel do Windows rodando. Nenhuma migration é necessária.

## Validação
TypeScript e build aprovados. Conferência no navegador em computador e celular: seleção mostra a foto da opção; Principal restaura a foto original sem mudar a escolha; Limpar seleção restaura a foto e bloqueia adicionar ao carrinho até escolher novamente. Nenhum banco remoto foi acessado.
