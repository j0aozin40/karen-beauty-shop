import { test, after } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import { PGlite } from '@electric-sql/pglite'

const db = new PGlite()
after(() => db.close())
const run = (sql, params = []) => db.query(sql, params)
const one = async (sql, params = []) => (await run(sql, params)).rows[0]
const option = (nome, estoque, ativo = true) => ({ tipo: 'cor', nome, sku: null, estoque, preco: 20, preco_promocional: null, imagem: null, ativo })
async function snapshot(id) {
  const p = await one('select * from produtos where id=$1', [id])
  const vs = (await run('select * from produto_variacoes where produto_id=$1 order by nome', [id])).rows.map(v => ({ ...v, preco: v.preco ?? p.preco }))
  return { p, vs }
}
async function salvar(s, vs = s.vs, excluir = [], confirmar = false, nome = s.p.nome, pricing = {}) {
  return (await one('select salvar_grupo_variacoes($1,$2::jsonb,$3::jsonb,$4::jsonb,$5) as p', [
    s.p.id || null, JSON.stringify({ nome, categoria: 'Teste', descricao: 'Descrição', atualizado_em: s.p.atualizado_em, estoque_original: s.p.estoque, ...pricing }),
    JSON.stringify(vs), JSON.stringify(excluir), confirmar,
  ])).p
}
async function pedido(id, variacaoId = null) {
  return (await one('select criar_pedido_reservado($1::jsonb,$2::jsonb) as p', [JSON.stringify({ nome: 'Local', email: 'local@example.test', whatsapp: '11999999999', tipo_entrega: 'pickup' }), JSON.stringify([{ produto_id: id, variacao_id: variacaoId, quantidade: 1 }])])).p
}
async function pagar(p, status = 'processed') {
  const mp = 'ORD-' + p.id
  await run('update pedidos set mercado_pago_order_id=$2 where id=$1', [p.id, mp])
  return one('select processar_pagamento_reservado($1,$2,$3,$4) as p', [p.id, mp, status, p.total])
}

test('cadastro único salva o conjunto de opções em uma transação', async t => {
  await db.exec('create role anon; create role authenticated; create role service_role; create schema auth; create table auth.users(id uuid primary key); create sequence public.produtos_id_seq;')
  await db.exec(await fs.readFile(new URL('../backup-seguranca/estrutura-public.sql', import.meta.url), 'utf8'))
  for (const file of ['202611100001_product_variations.sql', '202611100002_stock_reservations.sql', '202611110001_safe_variation_edit.sql', '202611110002_delete_variation_safely.sql', '202611110003_primary_variation.sql', '202611110004_unified_variation_editor.sql', '202611110005_pricing_for_unified_editor.sql', '202611110006_unlimited_pricing_percentages.sql']) {
    await db.exec(await fs.readFile(new URL('../supabase/migrations/' + file, import.meta.url), 'utf8'))
  }
  await db.exec("insert into categorias(nome) values('Teste'); insert into produtos(nome,categoria,preco,estoque) values('Legado','Teste',40,8);")
  let id, rosa
  await t.test('cadastro novo com opções ativas e inativas preserva soma e elimina o papel principal', async () => {
    await run("select setval('public.produtos_id_seq',1,false)")
    const r = await salvar({ p: { nome: 'Henna', estoque: 0 } }, [option('Rosa', 4), option('Preto', 4, false)])
    id = r.id
    assert.notEqual(id,1)
    assert.equal((await one('select nome from produtos where id=1')).nome,'Legado')
    const s = await snapshot(id)
    rosa = s.vs.find(v => v.nome === 'Rosa').id
    assert.equal(s.p.controla_variacoes, true)
    assert.equal(s.p.variacao_principal_id, null)
    assert.equal(s.p.estoque, 8)
    assert.equal(s.vs.length, 2)
    const c = (await one('select catalogo_disponivel() as c')).c.find(p => p.id === id)
    assert.equal(c.variacoes.length, 1)
    assert.equal(c.variacoes[0].id, rosa)
  })
  await t.test('pagamento durante a edição rejeita o cadastro antigo e não repõe estoque', async () => {
    const antigo = await snapshot(id)
    const q = await pedido(id, rosa)
    await pagar(q)
    await assert.rejects(salvar(antigo, antigo.vs, [], false, 'Nome antigo sobrescrito'), /mudou durante/)
    const atual = await snapshot(id)
    assert.equal(atual.p.estoque, 7)
    assert.equal(atual.p.nome, 'Henna')
    assert.equal(atual.vs.find(v => v.id === rosa).estoque, 3)
  })
  await t.test('erro em uma opção reverte nome, preços e todas as demais alterações', async () => {
    const s = await snapshot(id)
    const antes = await snapshot(id)
    await assert.rejects(salvar(s, s.vs.map(v => ({ ...v, sku: 'DUPLICADO', preco: 1 })), [], false, 'Não salvar'), /duplicate|unique/i)
    assert.deepEqual(await snapshot(id), antes)
  })
  await t.test('um salvar desativa as opções, preserva estoque e remove a antiga definição principal', async () => {
    let s = await snapshot(id)
    await run('select salvar_variacao_principal($1,$2,null,$3)', [id, rosa, s.p.atualizado_em])
    s = await snapshot(id)
    await salvar(s, s.vs.map(v => ({ ...v, ativo: false })))
    s = await snapshot(id)
    assert.equal(s.p.variacao_principal_id, null)
    assert.equal(s.p.estoque, 7)
    assert.equal(s.p.ativo, false)
    assert.equal((await one('select catalogo_disponivel() as c')).c.some(p => p.id === id), false)
    await salvar(s, s.vs.map(v => ({ ...v, ativo: true })))
  })
  await t.test('excluir opção com saldo falha sem apagar registros; opção vazia pode ser removida', async () => {
    let s = await snapshot(id)
    const remover = s.vs.find(v => v.id !== rosa)
    await assert.rejects(salvar(s, s.vs.filter(v => v.id !== remover.id), [remover], false, 'Não mudar'), /possui estoque/)
    assert.equal((await snapshot(id)).p.nome, 'Henna')
    await salvar(s, [...s.vs, option('Vazia', 0, false)])
    s = await snapshot(id)
    const vazia = s.vs.find(v => v.nome === 'Vazia')
    await salvar(s, s.vs.filter(v => v.id !== vazia.id), [vazia])
    assert.equal((await snapshot(id)).vs.length, 2)
    assert.equal((await snapshot(id)).p.estoque, 7)
  })
  await t.test('rascunho legado alterado em outro lugar é rejeitado antes da conversão', async () => {
    await run("insert into produto_variacoes(produto_id,tipo,nome,estoque) values(1,'cor','Clara',4),(1,'cor','Escura',4)")
    const s = await snapshot(1)
    await run("update produto_variacoes set nome='Alterada',atualizado_em=clock_timestamp() where id=$1", [s.vs[0].id])
    await assert.rejects(salvar(s), /variação mudou/)
    const atual = await snapshot(1)
    await salvar(atual, atual.vs.map((v, i) => ({ ...v, ativo: i === 0 })))
    const convertido = await snapshot(1)
    assert.equal(convertido.p.estoque, 8)
    assert.equal(convertido.p.controla_variacoes, true)
    assert.equal(convertido.vs.filter(v => !v.ativo).length, 1)
  })
  await t.test('pedido pendente bloqueia conversão; correção física exige confirmação explícita', async () => {
    const p = await one("insert into produtos(nome,categoria,preco,estoque) values('Legado pendente','Teste',10,2) returning *")
    const q = await pedido(p.id)
    const opcoes = [option('Única', 1)]
    await assert.rejects(salvar({ p }, opcoes), /pendentes/)
    assert.equal((await snapshot(p.id)).vs.length, 0)
    await pagar(q, 'canceled')
    let s = await snapshot(p.id)
    await assert.rejects(salvar(s, opcoes), /confirme o ajuste/)
    await salvar(s, opcoes, [], true)
    s = await snapshot(p.id)
    assert.equal(s.p.estoque, 1)
    assert.equal(s.vs.length, 1)
    assert.equal(s.vs[0].estoque, 1)
  })
  await t.test('fotos ficam nas opções e uma foto removida não reaparece por herança do agrupamento', async () => {
    await run("update produtos set imagem='https://example.test/antiga.jpg' where id=$1", [id])
    const s = await snapshot(id)
    await salvar(s, s.vs.map(v => ({ ...v, imagem: v.id === rosa ? 'https://example.test/rosa.jpg' : null })))
    const atual = await snapshot(id)
    assert.equal(atual.p.imagem, null)
    assert.equal(atual.vs.find(v => v.id === rosa).imagem, 'https://example.test/rosa.jpg')
    assert.equal(atual.vs.find(v => v.id !== rosa).imagem, null)
    assert.equal(atual.p.estoque, 7)
  })
  await t.test('custos antigos são preservados e a função não é pública', async () => {
    await run('update produtos set custo_aquisicao=12,taxa_mp_percentual=5 where id=$1', [id])
    await salvar(await snapshot(id))
    const s = await snapshot(id)
    assert.equal(Number(s.p.custo_aquisicao), 12)
    assert.equal(Number(s.p.taxa_mp_percentual), 5)
    assert.equal((await one("select has_function_privilege('anon','public.salvar_grupo_variacoes(integer,jsonb,jsonb,jsonb,boolean)','execute') as permitido")).permitido, false)
  })
  await t.test('custos e percentuais sem teto são salvos e rejeitam apenas números negativos', async () => {
    let s = await snapshot(id)
    await salvar(s, s.vs, [], false, s.p.nome, { custo_aquisicao: 10, custo_adicional: 2, taxa_mp_percentual: 20, taxas_adicionais_percentual: 10, margem_desejada_percentual: 30 })
    s = await snapshot(id)
    assert.equal(Number(s.p.custo_aquisicao), 10)
    assert.equal(Number(s.p.custo_adicional), 2)
    assert.equal(Number(s.p.margem_desejada_percentual), 30)
    await salvar(s, s.vs, [], false, s.p.nome, { taxa_mp_percentual: 100, taxas_adicionais_percentual: 90, margem_desejada_percentual: 250 })
    s = await snapshot(id)
    assert.equal(Number(s.p.taxa_mp_percentual), 100)
    assert.equal(Number(s.p.margem_desejada_percentual), 250)
    await assert.rejects(salvar(s, s.vs, [], false, s.p.nome, { taxa_mp_percentual: -1, taxas_adicionais_percentual: 0, margem_desejada_percentual: 0 }), /percentuais não podem ser negativos/i)
  })
})
