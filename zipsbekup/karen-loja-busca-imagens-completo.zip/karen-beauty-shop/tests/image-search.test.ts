import { test } from 'node:test'
import { Buffer } from 'node:buffer'
import assert from 'node:assert/strict'
import { PNG } from 'pngjs'
import jpeg from 'jpeg-js'
import { createHandler } from '../supabase/functions/search-product-images/handler.ts'
import { decodeImage } from '../supabase/functions/search-product-images/decode.ts'
import { safeURL, matches, quality, bounded } from '../supabase/functions/search-product-images/validation.ts'

const secret = 'local-test-image-secret-with-at-least-32-characters'
const identity = {nome:'Capinha Samsung A15',tipo:'cor',variacao:'Preta',sku:'A15-PRETA'}
const candidate = {...identity,url:'https://images.example.com/square.png',source:'https://vendor.example.com/a15',license:'supplier-contract-v1',evidence:'https://vendor.example.com/license',commercial:true,hotlink:true,attribution:'Fornecedor Exemplo',attribution_required:false}
function png(width=800,height=800) { return PNG.sync.write(new PNG({width,height})) }
const square = png(), landscape = png(1000,800)
const env: Record<string,string> = {IMAGE_SEARCH_SHARED_SECRET:secret,SUPABASE_URL:'https://db.example.com',SUPABASE_SERVICE_ROLE_KEY:'mock-only',IMAGE_PROVIDER_URL:'https://api.example.com/search',IMAGE_PROVIDER_TOKEN:'mock-token',IMAGE_PROVIDER_HOSTS:'api.example.com',IMAGE_HOSTS:'images.example.com',IMAGE_SOURCE_HOSTS:'vendor.example.com',IMAGE_LICENSES:'supplier-contract-v1'}
function setup(options: { candidates?: unknown[]; dns?: string[]; image?: Uint8Array; race?: boolean; missing?: boolean; offline?: boolean } = {}) {
  const calls: {url:string;body:any}[] = []
  const handler = createHandler({env:k=>options.missing && k==='IMAGE_PROVIDER_TOKEN' ? undefined : env[k],resolve:async()=>options.dns || ['93.184.216.34'],fetch:async(input,init)=>{
    const url=String(input); const body=init?.body ? JSON.parse(String(init.body)) : null; calls.push({url,body})
    if(url.endsWith('begin_product_image_search')) return Response.json({...identity,search_id:'11111111-1111-4111-8111-111111111111'})
    if(url.endsWith('publish_product_image')) return options.race ? Response.json({error:'changed'},{status:400}) : Response.json({imagem:body.p_metadata.url,metadata:body.p_metadata})
    if(url.includes('api.example.com')) { assert.equal(new Headers(init?.headers).get('Authorization'),'Bearer mock-token'); assert.deepEqual(body,{...identity,limit:8}); return Response.json({candidates: options.candidates || [{...candidate,url:'https://images.example.com/landscape.png'},candidate]}) }
    assert.equal(init?.redirect,'error')
    if(options.offline) return new Response(null,{status:404})
    if(url.includes('images.example.com')) return new Response(options.image || (url.includes('landscape')?landscape:square),{headers:{'Content-Type':'image/png'}})
    return new Response('Supplier product/license evidence')
  }})
  const request=(auth=secret,body:unknown={produto_id:1,variacao_id:'22222222-2222-4222-8222-222222222222'})=>new Request('https://edge.example.com',{method:'POST',headers:{'x-image-search-secret':auth},body:JSON.stringify(body)})
  return {handler,calls,request}
}
test('busca valida binário, identidade e licença; prefere quadrada e publica uma única vez',async()=>{
  const {handler,calls,request}=setup(); const r=await handler(request()); assert.equal(r.status,200)
  const published=calls.filter(c=>c.url.endsWith('publish_product_image')); assert.equal(published.length,1)
  assert.equal(published[0].body.p_metadata.url,candidate.url); assert.equal(published[0].body.p_metadata.width,800)
})
test('segredo ausente/incorreto, configuração incompleta e IDs inválidos não consultam catálogo',async()=>{
  let s=setup(); assert.equal((await s.handler(s.request('wrong'))).status,401); assert.equal(s.calls.length,0)
  s=setup({missing:true}); assert.equal((await s.handler(s.request())).status,503); assert.equal(s.calls.length,0)
  s=setup(); assert.equal((await s.handler(s.request(secret,{produto_id:-1}))).status,400); assert.equal(s.calls.length,0)
})
test('recusa variação, SKU, nome, licença e hotlink divergentes',async()=>{
  for(const change of [{variacao:'Azul'},{sku:'OTHER'},{nome:'Capinha Samsung A16'},{commercial:false},{hotlink:false},{attribution_required:true},{license:'unknown'},{evidence:''},{source:'https://untrusted.example.com/item'}]) {
    const s=setup({candidates:[{...candidate,...change}]}); assert.equal((await s.handler(s.request())).status,422)
    assert.equal(s.calls.some(c=>c.url.endsWith('publish_product_image')),false)
  }
  assert.equal(matches({...candidate,nome:' capinha samsung a15 '},identity,[candidate.license],['images.example.com'],['vendor.example.com']),true)
})
test('URLs perigosas, tokens temporários, portas e hosts não autorizados são recusados',()=>{
  for(const url of ['http://images.example.com/a','https://user:pass@images.example.com/a','https://images.example.com:444/a','https://images.example.com/a?token=secret','https://images.example.com/a#x','https://images.example.com.evil.com/a','https://127.0.0.1/a','https://[::1]/a']) assert.throws(()=>safeURL(url,['images.example.com']))
})
test('DNS privado, imagem corrompida, pequena, MIME falso e origem indisponível nunca publicam',async()=>{
  for(const options of [{dns:['127.0.0.1']},{dns:['10.0.0.1']},{dns:['169.254.169.254']},{dns:['::1']},{image:square.subarray(0,33)},{image:png(799,800)},{image:new TextEncoder().encode('<html>not image</html>')},{offline:true}]) {
    const s=setup(options); const r=await s.handler(s.request()); assert.ok([409,422].includes(r.status)); assert.equal(s.calls.some(c=>c.url.endsWith('publish_product_image')),false)
  }
  assert.throws(()=>decodeImage(square,'image/jpeg'))
  assert.throws(()=>quality({width:10000,height:10000}))
})
test('PNG/JPEG completos decodificam; CRC e arquivos truncados falham',()=>{
  assert.deepEqual(decodeImage(square,'image/png'),{width:800,height:800})
  const jpg=jpeg.encode({width:800,height:800,data:Buffer.alloc(800*800*4,255)},80).data
  assert.deepEqual(decodeImage(jpg,'image/jpeg'),{width:800,height:800})
  assert.throws(()=>decodeImage(jpg.subarray(0,100),'image/jpeg'))
  const corrupt=Buffer.from(square); corrupt[30]^=1; assert.throws(()=>decodeImage(corrupt,'image/png'))
})
test('publicação recusada pelo banco em edição concorrente devolve conflito',async()=>{
  const s=setup({race:true}); assert.equal((await s.handler(s.request())).status,409)
})
test('limite de leitura independe do Content-Length',async()=>{
  await assert.rejects(bounded(new Response('12345'),4),/limite/)
})
