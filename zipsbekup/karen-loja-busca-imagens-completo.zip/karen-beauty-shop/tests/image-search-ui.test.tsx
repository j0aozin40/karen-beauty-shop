import { test } from 'node:test'
import assert from 'node:assert/strict'
import { JSDOM } from 'jsdom'
import { act, createElement } from 'react'
import { createRoot } from 'react-dom/client'
import ProductImageSearch from '../src/ProductImageSearch'
import FamilyProductEditor from '../src/FamilyProductEditor'

test('interface protege foto manual e rascunho, publica só pelo serviço e apresenta falha',async()=>{
  const dom=new JSDOM('<div id="root"></div>',{url:'https://shop.example.com/admin'})
  // jsdom has no native dialog implementation; model only its open/close API.
  dom.window.HTMLDialogElement.prototype.showModal=function(){this.open=true}
  dom.window.HTMLDialogElement.prototype.close=function(){this.open=false}
  const oldFetch=globalThis.fetch
  Object.assign(globalThis,{window:dom.window,document:dom.window.document,IS_REACT_ACT_ENVIRONMENT:true})
  const root=createRoot(document.getElementById('root')!)
  const button=()=>[...document.querySelectorAll('button')].find(b=>b.textContent?.includes('Buscar imagem'))!
  const product={id:1,nome:'Capinha',categoria:'Teste',estoque:8,preco:20,ativo:true,imagem:'https://manual.example.com/foto.png'}
  let published=0; const states:boolean[]=[]; const requests:any[]=[]
  const onSaved=async()=>{published++}
  try {
    await act(async()=>{root.render(createElement(FamilyProductEditor,{produto:product,categorias:[],onClose:()=>{},onSaved}))})
    assert.equal(button().disabled,true); assert.match(document.body.textContent!,/Foto existente preservada/)
    await act(async()=>{root.render(createElement(FamilyProductEditor,{key:'new',produto:{...product,id:0,imagem:null},categorias:[],onClose:()=>{},onSaved}))})
    assert.equal(button().disabled,true); assert.match(document.body.textContent!,/Salve as alterações/)
    globalThis.fetch=async(input,init)=>{requests.push({url:input,body:JSON.parse(String(init?.body))}); return Response.json({imagem:'https://images.example.com/p.png',metadata:{}})}
    const props={produtoId:1,variacaoId:'22222222-2222-4222-8222-222222222222',blocked:'',onBusy:(b:boolean)=>states.push(b),onPublished:onSaved}
    await act(async()=>root.render(createElement(ProductImageSearch,props)))
    await act(async()=>button().click())
    assert.equal(published,1); assert.deepEqual(states,[true,false]); assert.deepEqual(requests,[{url:'/api/admin/imagens/buscar',body:{produto_id:1,variacao_id:props.variacaoId}}])
    assert.match(document.body.textContent!,/validada e publicada/)
    globalThis.fetch=async()=>Response.json({erro:'Nenhuma imagem aprovada.'},{status:422})
    await act(async()=>button().click()); assert.equal(published,1); assert.match(document.querySelector('[role=status]')!.textContent!,/Nenhuma imagem aprovada/)
  } finally { await act(async()=>root.unmount()); globalThis.fetch=oldFetch; dom.window.close() }
})
