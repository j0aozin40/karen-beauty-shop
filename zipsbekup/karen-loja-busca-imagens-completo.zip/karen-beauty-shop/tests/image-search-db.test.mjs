import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import { PGlite } from '@electric-sql/pglite'

test('migration aditiva, publicação atômica e permissões no PostgreSQL isolado',async t=>{
  const db=new PGlite(); const run=(sql,args=[])=>db.query(sql,args); const one=async(sql,args=[])=>(await run(sql,args)).rows[0]
  try {
    await db.exec('create role anon; create role authenticated; create role service_role; create schema auth; create table auth.users(id uuid primary key); create sequence produtos_id_seq;')
    await db.exec(await fs.readFile(new URL('../backup-seguranca/estrutura-public.sql',import.meta.url),'utf8'))
    for(const file of ['202611100001_product_variations.sql','202611100002_stock_reservations.sql','202611110001_safe_variation_edit.sql','202611110002_delete_variation_safely.sql','202611110003_primary_variation.sql','202611110004_unified_variation_editor.sql','202611110005_pricing_for_unified_editor.sql','202611110006_unlimited_pricing_percentages.sql']) await db.exec(await fs.readFile(new URL('../supabase/migrations/'+file,import.meta.url),'utf8'))
    // Synthetic fixtures only: same counts as the user's stated baseline, no real customer data.
    await db.exec("insert into produtos(nome,categoria,preco,estoque) select 'Produto '||n,'Teste',20,8 from generate_series(1,105)n; insert into pedidos(nome,whatsapp,email,tipo_entrega) select 'Local','000','local@example.test','pickup' from generate_series(1,12); insert into produto_variacoes(produto_id,tipo,nome,sku,estoque) values(2,'cor','Preta','SKU',8);")
    const snapshot=async()=>({p:(await run('select * from produtos order by id')).rows,o:(await run('select * from pedidos order by numero_pedido')).rows,v:(await run('select * from produto_variacoes')).rows})
    const before=await snapshot()
    await db.exec(await fs.readFile(new URL('../supabase/migrations/202611110007_product_image_search.sql',import.meta.url),'utf8'))
    assert.deepEqual(await snapshot(),before)
    const start=async(id,v=null)=>(await one('select begin_product_image_search($1,$2) as s',[id,v])).s
    const meta={url:'https://images.example.com/p.png',width:800,height:800,license:'contract',evidence:'https://vendor.example.com/license',commercial:true,hotlink:true}
    const publish=async(id,m=meta)=>one('select publish_product_image($1,$2::jsonb) as s',[id,JSON.stringify(m)])
    await t.test('legado recebe apenas imagem e timestamp; estoque, pedidos e preço preservados',async()=>{
      const s=await start(1); await publish(s.search_id)
      const p=await one('select * from produtos where id=1'); assert.equal(p.imagem,meta.url); assert.equal(p.estoque,8); assert.equal(p.preco,'20'); assert.equal(p.controla_variacoes,false)
      assert.deepEqual((await snapshot()).o,before.o)
      await assert.rejects(publish(s.search_id),/concluída/)
      await assert.rejects(start(1),/preservada/)
    })
    await t.test('foto manual adicionada durante busca nunca é substituída',async()=>{
      const s=await start(3); await run("update produtos set imagem='https://manual.example.com/foto.png' where id=3")
      await assert.rejects(publish(s.search_id),/preservada/); assert.equal((await one('select imagem from produtos where id=3')).imagem,'https://manual.example.com/foto.png')
    })
    await t.test('busca por variação publica só no alvo e bloqueia alterações concorrentes',async()=>{
      const v=before.v[0]; const s=await start(2,v.id)
      await publish(s.search_id); assert.equal((await one('select imagem from produto_variacoes where id=$1',[v.id])).imagem,meta.url)
      assert.equal((await one('select imagem from produtos where id=2')).imagem,null)
      const other=await start(4); await run("update produtos set nome='Mudou' where id=4")
      await assert.rejects(publish(other.search_id),/alterado/)
      const timestamp=await start(5); await run('update produtos set atualizado_em=clock_timestamp() where id=5'); await assert.rejects(publish(timestamp.search_id),/alterado/)
    })
    await t.test('intervalo entre buscas, expiração e resolução também protegidos no banco',async()=>{
      const s=await start(6); await assert.rejects(start(6),/um minuto/)
      await assert.rejects(publish(s.search_id,{...meta,width:799}),/incompleta/)
      await run("update product_image_searches set criado_em=now()-interval '3 minutes' where id=$1",[s.search_id]); await assert.rejects(publish(s.search_id),/expirada/)
      const other=await start(7); await assert.rejects(publish(other.search_id,{...meta,commercial:false}),/incompleta/)
    })
    await t.test('anon e authenticated não têm acesso à tabela nem às RPCs',async()=>{
      for(const role of ['anon','authenticated']) {
        assert.equal((await one("select has_table_privilege($1,'product_image_searches','SELECT') as ok",[role])).ok,false)
        for(const signature of ['begin_product_image_search(integer,uuid)','publish_product_image(uuid,jsonb)']) assert.equal((await one('select has_function_privilege($1,$2,\'EXECUTE\') as ok',[role,signature])).ok,false)
        await db.exec('set role '+role); await assert.rejects(run('select * from product_image_searches'),/permission denied/); await db.exec('reset role')
      }
      assert.equal((await one("select relrowsecurity as ok from pg_class where oid='product_image_searches'::regclass")).ok,true)
      assert.equal((await one('select count(*)::int as n from produtos')).n,105); assert.equal((await one('select count(*)::int as n from pedidos')).n,12)
    })
  } finally { await db.close() }
})
