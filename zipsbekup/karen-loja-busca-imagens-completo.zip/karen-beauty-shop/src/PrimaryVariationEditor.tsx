import { useCallback, useEffect, useState } from 'react'
import { variationTypes } from './variationTypes'

type Option = { id?: string; tipo: string; nome: string; sku: string; estoque: number; preco: number | string; preco_promocional: number | string; imagem: string; ativo: boolean; atualizado_em?: string }
type Snapshot = { atualizado_em: string; controla_variacoes: boolean; variacao_principal_id?: string; produto_variacoes: Option[] }
const empty = (): Option => ({ tipo: 'cor', nome: '', sku: '', estoque: 0, preco: '', preco_promocional: '', imagem: '', ativo: true })

export default function PrimaryVariationEditor({ produtoId, revision, onUpdate, onEditingChange, onBusyChange }: { produtoId: number; revision: number; onUpdate: () => Promise<void>; onEditingChange: (value: boolean) => void; onBusyChange: (value: boolean) => void }) {
  const [p, setP] = useState<Snapshot | null>(null)
  const [escolha, setEscolha] = useState('')
  const [draft, setDraft] = useState<Option | null>(null)
  const [estoqueInicial, setEstoqueInicial] = useState(0)
  const [busy, setBusy] = useState(false)
  const [mensagem, setMensagem] = useState('')
  const [erro, setErro] = useState(false)
  const principal = p?.produto_variacoes.find(v => v.id === p.variacao_principal_id)
  const meta = variationTypes[draft?.tipo || 'cor'] || variationTypes.outro
  const carregar = useCallback(async () => {
    const r = await fetch('/api/admin/produtos', { cache: 'no-store' })
    const data = await r.json()
    if (!r.ok) throw new Error(data.erro || 'Não foi possível carregar a opção principal.')
    const atual = data.produtos.find((v: { id: number }) => v.id === produtoId)
    if (!atual) throw new Error('Produto não encontrado.')
    atual.produto_variacoes = (atual.produto_variacoes || []).map((v: Option) => ({ ...v, sku: v.sku || '', imagem: v.imagem || '', preco: v.preco ?? '', preco_promocional: v.preco_promocional ?? '' }))
    setP(atual); setEscolha(atual.variacao_principal_id || '')
  }, [produtoId])
  useEffect(() => { void carregar().catch(e => { setMensagem(e.message); setErro(true) }) }, [carregar, revision])
  useEffect(() => { onEditingChange(!!draft) }, [draft, onEditingChange])
  useEffect(() => { onBusyChange(busy) }, [busy, onBusyChange])

  async function salvar() {
    if (!p || busy) return
    setBusy(true); setMensagem(''); setErro(false)
    let gravou = false
    try {
      const editar = Boolean(draft?.id)
      const body = editar ? { ...draft!, estoque: draft!.estoque === estoqueInicial ? undefined : draft!.estoque } : {
        variacao_id: draft ? null : escolha,
        atualizado_em: p.atualizado_em,
        dados: draft,
      }
      const r = await fetch(`/api/admin/produtos/${produtoId}/${editar ? 'variacoes' : 'variacao-principal'}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      const data = await r.json()
      if (!r.ok) throw new Error(data.erro || 'Não foi possível salvar a opção principal.')
      gravou = true; setDraft(null); await carregar(); await onUpdate()
      setMensagem(editar ? 'Dados da opção principal atualizados.' : 'Opção principal definida. Ela participa da mesma lista e do mesmo estoque das demais variações.')
    } catch (e) { setErro(true); setMensagem((gravou ? 'A opção foi salva, mas a tela precisa ser atualizada. ' : '') + (e instanceof Error ? e.message : 'Erro ao salvar.')) } finally { setBusy(false) }
  }

  return <section className="primary-variation-editor" aria-label="Opção principal do produto" aria-busy={busy}>
    <div className="variation-section-heading"><div><span className="editor-eyebrow">OPÇÃO PRINCIPAL</span><h3>O produto principal também é uma variação</h3><p>Defina a opção que aparece primeiro. Ela continua selecionável junto das outras.</p></div></div>
    {principal && <div className="primary-option-summary"><div><span className="variation-badge active">Principal</span><strong>{principal.nome}</strong><small>{variationTypes[principal.tipo]?.label || principal.tipo} · SKU: {principal.sku || 'Não informado'} · {principal.estoque} unidades</small></div><button type="button" className="admin-action secondary" disabled={busy || !!draft} onClick={() => { setDraft({ ...principal }); setEstoqueInicial(principal.estoque); setMensagem('') }}>Editar opção principal</button></div>}
    {!principal && <p className="editor-note">Nenhuma opção principal definida. Escolha uma opção existente ou cadastre a original abaixo.</p>}
    {!draft && <div className="primary-option-choose"><label>Usar uma variação existente<select aria-label="Variação principal" value={escolha} disabled={busy || !p} onChange={e => setEscolha(e.target.value)}><option value="">Selecione uma opção…</option>{p?.produto_variacoes.filter(v => v.ativo).map(v => <option value={v.id} key={v.id}>{variationTypes[v.tipo]?.label || v.tipo}: {v.nome} · {v.estoque} unidades</option>)}</select></label><div className="variation-row-actions"><button type="button" className="admin-action primary" disabled={busy || !escolha || escolha === p?.variacao_principal_id} onClick={() => void salvar()}>Definir como principal</button><button type="button" className="admin-action secondary" disabled={busy || !p} onClick={() => { setDraft(empty()); setEstoqueInicial(0); setMensagem('') }}>Cadastrar opção original</button><button type="button" className="admin-action subtle" disabled={busy} onClick={() => void carregar().catch(e => { setErro(true); setMensagem(e.message) })}>↻ Atualizar</button></div></div>}
    {draft && <form className="primary-option-form" onSubmit={e => { e.preventDefault(); void salvar() }}>
      <fieldset disabled={busy} className="variation-form-fields"><div className="variation-fields">
        <label>Tipo da opção principal<select aria-label="Tipo da opção principal" value={draft.tipo} onChange={e => setDraft({ ...draft, tipo: e.target.value })}>{Object.entries(variationTypes).map(([key,v]) => <option value={key} key={key}>{v.label}</option>)}</select></label>
        <label>{meta.field}<input aria-label={meta.field} required maxLength={120} placeholder={meta.placeholder} value={draft.nome} onChange={e => setDraft({ ...draft, nome: e.target.value })} /></label>
        <label>SKU da opção principal<input value={draft.sku} maxLength={100} onChange={e => setDraft({ ...draft, sku: e.target.value })} /></label>
        <label>Estoque desta opção<input aria-label="Estoque da opção principal" required type="number" min="0" step="1" value={draft.estoque} onChange={e => setDraft({ ...draft, estoque: Number(e.target.value) })} /></label>
        <label>Preço desta opção<input type="number" min="0" step="0.01" value={draft.preco} placeholder="Vazio = preço base" onChange={e => setDraft({ ...draft, preco: e.target.value })} /><small>Deixe vazio para usar o preço base da aba Preços.</small></label>
        <label>Preço promocional<input type="number" min="0" step="0.01" value={draft.preco_promocional} onChange={e => setDraft({ ...draft, preco_promocional: e.target.value })} /></label>
      </div></fieldset>
      <p className="editor-note">O estoque geral é a soma de todas as opções. Não copie o total para esta opção: informe somente as unidades físicas dela. Uma nova opção começa com zero e não modifica as quantidades das outras.</p>
      <div className="variation-row-actions"><button type="submit" className="admin-action primary" disabled={busy}>{busy ? 'Salvando…' : 'Salvar opção principal'}</button><button type="button" className="admin-action secondary" disabled={busy} onClick={() => setDraft(null)}>Cancelar</button></div>
    </form>}
    {p && !p.controla_variacoes && <p className="editor-note">Após cadastrar e distribuir as opções, use Ativar variações no catálogo na aba Variações. A conversão confere a soma do estoque original.</p>}
    {mensagem && <p className={`variation-feedback ${erro ? 'error' : 'success'}`} role={erro ? 'alert' : 'status'}>{mensagem}</p>}
  </section>
}
