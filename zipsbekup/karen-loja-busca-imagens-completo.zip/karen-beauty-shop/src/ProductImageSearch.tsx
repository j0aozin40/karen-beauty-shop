import { useState } from 'react'
import { searchProductImage } from './imageSearchService'

export default function ProductImageSearch({ produtoId, variacaoId, blocked, onBusy, onPublished }: {
  produtoId: number; variacaoId?: string; blocked: string; onBusy: (busy:boolean)=>void; onPublished:()=>Promise<void>
}) {
  const [message,setMessage] = useState('')
  const [running,setRunning] = useState(false)
  async function search() {
    if (blocked || running) return
    setRunning(true); onBusy(true); setMessage('Buscando e validando imagem…')
    try {
      await searchProductImage(produtoId,variacaoId)
      setMessage('Imagem validada e publicada. Atualizando o cadastro…')
      await onPublished()
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Busca indisponível.') }
    finally { setRunning(false); onBusy(false) }
  }
  return <div className="product-image-search">
    <button type="button" className="admin-action secondary" disabled={Boolean(blocked) || running} onClick={()=>void search()}>{running ? 'Validando…' : 'Buscar imagem automaticamente'}</button>
    <small>{blocked || 'Publica após validar: produto e variação exatos, mínimo 800 × 800, preferência quadrada e uso autorizado. PNG/JPEG; nenhuma foto existente é substituída.'}</small>
    {message && <p role="status" aria-live="polite">{message}</p>}
  </div>
}
