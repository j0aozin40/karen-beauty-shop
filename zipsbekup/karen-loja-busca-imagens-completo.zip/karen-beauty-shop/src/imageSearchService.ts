export async function searchProductImage(produto_id: number, variacao_id?: string) {
  const response = await fetch('/api/admin/imagens/buscar', { method:'POST', credentials:'same-origin',
    headers:{'Content-Type':'application/json'}, body: JSON.stringify({produto_id,variacao_id}) })
  const data = await response.json()
  if (!response.ok) throw new Error(data.erro || 'Não foi possível buscar a imagem.')
  return data as { imagem: string; metadata: {source:string;license:string;width:number;height:number} }
}
