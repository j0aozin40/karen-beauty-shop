import { Buffer } from 'node:buffer'
import { PNG } from 'pngjs'
import jpeg from 'jpeg-js'
import { dimensions, quality } from './validation.ts'

export function decodeImage(bytes: Uint8Array, mime: string) {
  const header = dimensions(bytes,mime)
  quality(header) // Bound allocation before decoding untrusted compressed bytes.
  const decoded = mime === 'image/png' ? PNG.sync.read(Buffer.from(bytes),{checkCRC:true}) :
    jpeg.decode(bytes,{useTArray:true,tolerantDecoding:false,maxResolutionInMP:4,maxMemoryUsageInMB:64})
  if (!decoded.data?.length || decoded.width !== header.width || decoded.height !== header.height) throw new Error('Imagem corrompida.')
  return header
}
