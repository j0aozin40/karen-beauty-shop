import { bounded, matches, quality, safeURL, type Candidate, type Identity } from './validation.ts'
import { decodeImage } from './decode.ts'
type Dependencies = { env: (key: string) => string | undefined; fetch: typeof fetch; resolve: (host: string) => Promise<string[]> }
const json = (value: unknown, status = 200) => Response.json(value, { status })
const publicIPv4 = (ip: string) => {
  const n = ip.split('.').map(Number)
  return n.length === 4 && n.every(x => Number.isInteger(x) && x >= 0 && x <= 255) &&
    ![0,10,127].includes(n[0]) && n[0] < 224 && !(n[0] === 169 && n[1] === 254) &&
    !(n[0] === 172 && n[1] >= 16 && n[1] <= 31) && !(n[0] === 192 && [0,168].includes(n[1])) &&
    !(n[0] === 100 && n[1] >= 64 && n[1] <= 127) && !(n[0] === 198 && [18,19,51].includes(n[1])) && !(n[0] === 203 && n[1] === 0)
}
const publicIP = (ip: string) => ip.includes(':') ? /^[23][0-9a-f]{3}:/i.test(ip) &&
  !/^2002:/i.test(ip) && !/^2001:(?:0*:|db8:|0*2:|0*10:|0*20:)/i.test(ip) : publicIPv4(ip)
export function createHandler(d: Dependencies) {
  const env = (k: string) => d.env(k) || ''
  const list = (k: string) => env(k).split(',').map(s => s.trim()).filter(Boolean)
  async function get(url: URL, headers?: HeadersInit) {
    const addresses = await d.resolve(url.hostname)
    if (!addresses.length || !addresses.every(publicIP)) throw new Error('Origem de rede não autorizada.')
    return d.fetch(url, { headers, redirect: 'error', signal: AbortSignal.timeout(8000) })
  }
  async function rpc(name: string, body: unknown) {
    const response = await d.fetch(`${env('SUPABASE_URL')}/rest/v1/rpc/${name}`, { method: 'POST',
      headers: { apikey: env('SUPABASE_SERVICE_ROLE_KEY'), Authorization: `Bearer ${env('SUPABASE_SERVICE_ROLE_KEY')}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body), signal: AbortSignal.timeout(8000), redirect: 'error' })
    if (!response.ok) throw new Error('Cadastro indisponível, alterado, com foto existente ou em intervalo entre buscas.')
    return response.json()
  }
  return async (request: Request) => {
    if (request.method !== 'POST') return json({ erro: 'Método não permitido.' }, 405)
    const secret = env('IMAGE_SEARCH_SHARED_SECRET')
    const received = request.headers.get('x-image-search-secret') || ''
    const hash = async (s: string) => new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))
    const [a,b] = await Promise.all([hash(secret),hash(received)])
    let diff = 0; for (let i=0;i<a.length;i++) diff |= a[i]^b[i]
    if (secret.length < 32 || diff !== 0) return json({ erro: 'Acesso não autorizado.' }, 401)
    if (!env('IMAGE_PROVIDER_URL') || !env('IMAGE_PROVIDER_TOKEN') || !list('IMAGE_HOSTS').length || !list('IMAGE_SOURCE_HOSTS').length || !list('IMAGE_LICENSES').length) return json({ erro: 'Configure o fornecedor autorizado e suas credenciais antes de buscar.' }, 503)
    let input: { produto_id: number; variacao_id?: string }
    try {
      input = JSON.parse(new TextDecoder().decode(await bounded(request, 4096)))
    } catch { return json({ erro: 'Entrada inválida.' }, 400) }
    if (!input || typeof input !== 'object' || !Number.isSafeInteger(input.produto_id) || input.produto_id < 1 || (input.variacao_id != null && (typeof input.variacao_id !== 'string' || !/^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(input.variacao_id)))) return json({ erro: 'Produto ou variação inválidos.' }, 400)
    try {
      const endpoint = new URL(env('IMAGE_PROVIDER_URL'))
      safeURL(endpoint.href, list('IMAGE_PROVIDER_HOSTS'))
      const identity: Identity & {search_id: string} = await rpc('begin_product_image_search', {p_produto:input.produto_id,p_variacao:input.variacao_id || null})
      // Provider receives only catalog identity, never customer/order information or database credentials.
      const addresses = await d.resolve(endpoint.hostname)
      if (!addresses.length || !addresses.every(publicIP)) throw new Error('Fornecedor não autorizado.')
      const response = await d.fetch(endpoint, { method: 'POST', headers: { Authorization: `Bearer ${env('IMAGE_PROVIDER_TOKEN')}`, 'Content-Type':'application/json' },
        body: JSON.stringify({nome:identity.nome,tipo:identity.tipo,variacao:identity.variacao,sku:identity.sku,limit:8}), redirect:'error',signal:AbortSignal.timeout(8000) })
      const data = JSON.parse(new TextDecoder().decode(await bounded(response, 128*1024)))
      if (!Array.isArray(data.candidates)) throw new Error('Resposta inválida do fornecedor.')
      const validated: (Candidate & {width:number;height:number;score:number})[] = []
      await Promise.all(data.candidates.slice(0,8).map(async (candidate: Candidate) => {
        if (!matches(candidate,identity,list('IMAGE_LICENSES'),list('IMAGE_HOSTS'),list('IMAGE_SOURCE_HOSTS'))) return
        try {
          const image = await get(safeURL(candidate.url,list('IMAGE_HOSTS')))
          const bytes = await bounded(image,5*1024*1024)
          const size = decodeImage(bytes,(image.headers.get('Content-Type') || '').split(';')[0].trim())
          const score = quality(size)
          // License evidence and product page must still be reachable on the authorized origin.
          for (const link of new Set<string>([candidate.source,candidate.evidence])) await bounded(await get(safeURL(link,list('IMAGE_SOURCE_HOSTS'))),512*1024)
          validated.push({...candidate,...size,score})
        } catch { /* Reject this candidate, never weaken validation. */ }
      }))
      validated.sort((a,b)=>a.score-b.score || b.width*b.height-a.width*a.height)
      const winner = validated[0]
      if (!winner) return json({erro:'Nenhuma imagem passou pela correspondência exata, licença, URL e resolução mínima de 800 × 800.'},422)
      const result = await rpc('publish_product_image',{p_search:identity.search_id,p_metadata:{...winner,validated_at:new Date().toISOString()}})
      return json(result)
    } catch { return json({erro:'Busca não concluída. Verifique fornecedor, intervalo entre buscas e se o cadastro ou a foto mudou. Nenhuma imagem foi substituída.'},409) }
  }
}
