import { createHandler } from './handler.ts'
Deno.serve(createHandler({ env: key => Deno.env.get(key), fetch,
  resolve: async host => {
    const records = await Promise.all(['A','AAAA'].map(async type => {
      try { return await Deno.resolveDns(host,type as 'A' | 'AAAA') }
      catch (error) { if (error instanceof Deno.errors.NotFound) return []; throw error }
    }))
    return records.flat()
  } }))
