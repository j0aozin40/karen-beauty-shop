export type Identity = { nome: string; tipo: string; variacao: string; sku: string | null }
export type Candidate = Identity & { url: string; source: string; license: string; evidence: string; commercial: boolean; hotlink: boolean; attribution: string; attribution_required: boolean }
export const normalize = (s: string) => s.normalize('NFKC').trim().toLocaleLowerCase('pt-BR').replace(/\s+/g, ' ')

// Exact hosts only. No wildcard domains or URL credentials; query tokens and expiring URLs are refused.
export function safeURL(value: string, hosts: string[]) {
  const u = new URL(value)
  if (value.length > 2048 || u.protocol !== 'https:' || u.username || u.password || u.port || u.hash || u.search ||
    !hosts.includes(u.hostname) || !/^[a-z0-9.-]+\.[a-z]{2,}$/.test(u.hostname) ||
    /(^|\.)(localhost|local|internal|test|invalid)$/.test(u.hostname)) throw new Error('URL não autorizada.')
  return u
}

export function matches(c: Candidate, identity: Identity, licenses: string[], imageHosts: string[], sourceHosts: string[]) {
  if (!c || typeof c !== 'object' || !['nome','tipo','variacao','url','source','license','evidence','attribution'].every(k => typeof c[k as keyof Candidate] === 'string')) return false
  if (c.commercial !== true || c.hotlink !== true || c.attribution_required !== false || !licenses.includes(c.license) || !c.evidence.trim()) return false
  if (normalize(c.nome) !== normalize(identity.nome) || normalize(c.tipo) !== normalize(identity.tipo) || normalize(c.variacao) !== normalize(identity.variacao)) return false
  if (identity.sku && c.sku !== identity.sku) return false
  try { safeURL(c.url, imageHosts); safeURL(c.source, sourceHosts); safeURL(c.evidence, sourceHosts) } catch { return false }
  return true
}

// Dimensions from actual file headers, never from provider metadata. Unsupported formats fail closed.
export function dimensions(b: Uint8Array, mime: string): { width: number; height: number } {
  const v = new DataView(b.buffer, b.byteOffset, b.byteLength)
  if (mime === 'image/png' && b.length >= 33 && [137,80,78,71,13,10,26,10].every((x,i)=>b[i]===x) && v.getUint32(8) === 13 && v.getUint32(12) === 0x49484452) return { width: v.getUint32(16), height: v.getUint32(20) }
  if (mime === 'image/jpeg' && b[0] === 255 && b[1] === 216) {
    let p = 2
    while (p + 4 <= b.length) {
      if (b[p++] !== 255) break
      while (b[p] === 255) p++
      const marker = b[p++]
      if (marker === 0xda || marker === 0xd9) break
      const len = v.getUint16(p)
      if (len < 2 || p + len > b.length) break
      if ([0xc0,0xc1,0xc2].includes(marker) && len >= 8) return { height: v.getUint16(p+3), width: v.getUint16(p+5) }
      p += len
    }
  }
  throw new Error('Formato ou cabeçalho de imagem inválido. Use PNG/JPEG.')
}

export function quality(d: {width: number; height: number}) {
  if (d.width < 800 || d.height < 800 || d.width > 4096 || d.height > 4096 || d.width * d.height > 4_000_000) throw new Error('Resolução fora do limite permitido.')
  return Math.abs(Math.log(d.width / d.height))
}

export async function bounded(response: Response | Request, max: number) {
  if ((response instanceof Response && !response.ok) || !response.body) throw new Error('Origem indisponível.')
  const reader = response.body.getReader(); const parts: Uint8Array[] = []; let size = 0
  try {
    for (;;) { const { done, value } = await reader.read(); if (done) break; size += value.length; if (size > max) throw new Error('Resposta excede o limite.'); parts.push(value) }
  } finally { await reader.cancel() }
  const result = new Uint8Array(size); let offset = 0
  for (const part of parts) { result.set(part, offset); offset += part.length }
  return result
}
