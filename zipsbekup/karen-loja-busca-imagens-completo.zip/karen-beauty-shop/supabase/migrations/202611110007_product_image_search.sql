begin;
-- Additive migration: no backfill and no UPDATE/DELETE of existing catalog/order rows.
create table public.product_image_searches (
  id uuid primary key default gen_random_uuid(),
  produto_id integer not null references public.produtos(id) on delete cascade,
  variacao_id uuid references public.produto_variacoes(id) on delete cascade,
  criado_em timestamptz not null default now(),
  snapshot jsonb not null,
  status text not null default 'searching' check (status in ('searching','published')),
  metadata jsonb
);
create index product_image_searches_target on public.product_image_searches(produto_id, criado_em desc);
alter table public.product_image_searches enable row level security;
revoke all on public.product_image_searches from public, anon, authenticated;
grant all on public.product_image_searches to service_role;

create function public.begin_product_image_search(p_produto integer, p_variacao uuid default null)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare p public.produtos; v public.produto_variacoes; s jsonb; search_id uuid;
begin
  select * into p from public.produtos where id=p_produto for update;
  if not found then raise exception 'Produto não encontrado.'; end if;
  if nullif(btrim(p.imagem),'') is not null then raise exception 'Foto existente preservada.'; end if;
  if p_variacao is not null then
    select * into v from public.produto_variacoes where id=p_variacao and produto_id=p.id for update;
    if not found then raise exception 'Variação não encontrada.'; end if;
    if nullif(btrim(v.imagem),'') is not null then raise exception 'Foto existente preservada.'; end if;
  elsif p.controla_variacoes then raise exception 'Selecione uma variação.';
  end if;
  if exists(select 1 from public.product_image_searches where produto_id=p.id and criado_em > now()-interval '60 seconds') then
    raise exception 'Aguarde um minuto entre buscas deste produto.';
  end if;
  s := jsonb_build_object('nome',p.nome,'tipo',coalesce(v.tipo,''),'variacao',coalesce(v.nome,''),'sku',v.sku,
    'produto_atualizado',p.atualizado_em,'variacao_atualizada',v.atualizado_em);
  insert into public.product_image_searches(produto_id,variacao_id,snapshot) values(p.id,p_variacao,s) returning id into search_id;
  return s || jsonb_build_object('search_id',search_id);
end $$;

create function public.publish_product_image(p_search uuid, p_metadata jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare a public.product_image_searches; p public.produtos; v public.produto_variacoes;
begin
  select * into a from public.product_image_searches where id=p_search;
  if not found then raise exception 'Busca não encontrada.'; end if;
  -- Same lock order as the existing variation editor: product, variation, audit.
  select * into p from public.produtos where id=a.produto_id for update;
  if not found then raise exception 'Produto removido.'; end if;
  if a.variacao_id is not null then
    select * into v from public.produto_variacoes where id=a.variacao_id and produto_id=p.id for update;
    if not found then raise exception 'Variação removida.'; end if;
  end if;
  select * into a from public.product_image_searches where id=p_search for update;
  if a.status <> 'searching' or a.criado_em < now()-interval '2 minutes' then raise exception 'Busca expirada ou concluída.'; end if;
  if nullif(btrim(p.imagem),'') is not null or nullif(btrim(v.imagem),'') is not null or
    a.snapshot->>'nome' is distinct from p.nome or
    a.snapshot->>'produto_atualizado' is distinct from to_jsonb(p.atualizado_em)#>>'{}' or
    (a.variacao_id is not null and (a.snapshot->>'variacao' is distinct from v.nome or
      a.snapshot->>'tipo' is distinct from v.tipo or a.snapshot->>'sku' is distinct from v.sku or
      a.snapshot->>'variacao_atualizada' is distinct from to_jsonb(v.atualizado_em)#>>'{}')) then
    raise exception 'Cadastro alterado durante a busca. Foto preservada; reabra o cadastro.';
  end if;
  if coalesce((p_metadata->>'width')::integer,0)<800 or coalesce((p_metadata->>'height')::integer,0)<800 or
    coalesce(p_metadata->>'url','') !~ '^https://[^/@:]+/' or
    coalesce(p_metadata->>'license','')='' or coalesce(p_metadata->>'evidence','')='' or
    (p_metadata->>'commercial')::boolean is distinct from true or (p_metadata->>'hotlink')::boolean is distinct from true then
    raise exception 'Validação incompleta.';
  end if;
  if a.variacao_id is null then
    update public.produtos set imagem=p_metadata->>'url', atualizado_em=now() where id=p.id;
  else
    update public.produto_variacoes set imagem=p_metadata->>'url', atualizado_em=now() where id=v.id;
  end if;
  update public.product_image_searches set status='published',metadata=p_metadata where id=a.id;
  return jsonb_build_object('imagem',p_metadata->>'url','metadata',p_metadata);
end $$;
revoke all on function public.begin_product_image_search(integer,uuid) from public,anon,authenticated;
revoke all on function public.publish_product_image(uuid,jsonb) from public,anon,authenticated;
grant execute on function public.begin_product_image_search(integer,uuid) to service_role;
grant execute on function public.publish_product_image(uuid,jsonb) to service_role;
commit;
