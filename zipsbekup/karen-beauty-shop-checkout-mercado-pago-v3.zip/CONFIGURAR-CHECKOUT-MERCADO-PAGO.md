# Checkout Mercado Pago

O formulário atual salva o pedido no Supabase. Com esta integração, o servidor cria uma order no Checkout Pro, devolve o cliente para a página segura do Mercado Pago e recebe o status atualizado por webhook. A confirmação só é confiável quando chega do webhook e é conferida na API do Mercado Pago.

## 1. Atualizar a estrutura do banco

No Supabase do projeto correto, abra **SQL Editor**, cole e execute o conteúdo de `supabase/migrations/202611090001_mercado_pago_checkout.sql`. Essa alteração apenas acrescenta colunas e um índice; não edita nem remove pedidos ou produtos existentes.

## 2. Configurar as credenciais no servidor

No Codespaces, abra `.env.local` e acrescente as variáveis abaixo, preservando as outras que já existem:

```env
MERCADO_PAGO_ACCESS_TOKEN=COLE_A_CHAVE_PRIVADA_DO_MERCADO_PAGO
MERCADO_PAGO_WEBHOOK_SECRET=COLE_A_ASSINATURA_SECRETA_DO_WEBHOOK
PUBLIC_APP_URL=https://SEU-ENDERECO-PUBLICO-5173.app.github.dev
```

Use inicialmente a credencial de **teste** do Mercado Pago. O token e a assinatura secreta ficam somente em `.env.local`, no servidor. Não os envie no chat, não os coloque em arquivos `VITE_*` e não os publique no GitHub.

`PUBLIC_APP_URL` é o endereço https do site na porta 5173, sem barra no final.

## 3. Apontar o webhook do Mercado Pago

Na aplicação do Mercado Pago, configure notificações de pagamento para o evento **Order (Mercado Pago)** e use como URL o endereço https público da porta 3001, terminado em:

```text
/api/pagamentos/mercado-pago/webhook
```

Copie a **assinatura secreta** gerada pelo Mercado Pago para `MERCADO_PAGO_WEBHOOK_SECRET`. A porta 3001 precisa estar acessível pelo endereço encaminhado do Codespaces para o teste. Não use `localhost` na URL do webhook.

## 4. Reiniciar e testar

Salve `.env.local` e reinicie o servidor. Faça primeiro uma compra de teste com credenciais e comprador de teste do Mercado Pago. A compra cria um pedido real no banco, por isso use um item de valor baixo e confirme que o ambiente é de teste.

O cliente será redirecionado ao Checkout Pro. O painel deve mostrar **Aguardando pagamento** até o webhook confirmado atualizar o pedido. Os avisos por e-mail e WhatsApp só serão enviados depois da confirmação do pagamento; o WhatsApp do cliente continua dependendo da autorização opcional no checkout. Só marque o pedido como preparado depois de conferir **Confirmado**.

Antes de receber pagamentos reais, troque para as credenciais de produção e configure um endereço HTTPS permanente para o site e para o webhook. O endereço temporário do Codespaces serve para desenvolvimento, não para manter a loja online.
