# Categorias e fotos de produtos

## O que foi preparado

- Painel administrativo com criação, renomeação e exclusão de categorias. A exclusão é recusada quando há produtos vinculados.
- Envio de fotos JPG, PNG ou WebP de até 5 MB pelo painel. Os arquivos são enviados ao bucket `product-photos` e a URL fica na coluna existente `produtos.imagem`.
- Loja pública carrega produtos ativos do banco e mostra a foto quando disponível. A validação do pedido lê preço e estoque atuais do mesmo catálogo.
- Migração que cria a tabela de categorias, importa nela os nomes de categoria existentes sem alterar linhas de produto e cria o bucket público. A coluna de foto já existe e será reutilizada.

## Antes de usar

Revise `supabase/migrations/202611080001_categories_and_product_photos.sql` contra o schema do projeto e aplique-a manualmente no ambiente correto. Ela não foi executada durante esta alteração. Faça backup conforme o processo habitual antes de aplicar alterações de schema.

O servidor precisa usar uma chave privada de backend com acesso ao Storage e às tabelas. Nunca coloque essa chave no frontend. O bucket configurado por `PRODUCT_PHOTO_BUCKET` deve existir e ser público; se a variável for definida para outro nome, crie esse bucket com as mesmas restrições.

O build não foi executado porque este ambiente não tem npm nem dependências instaladas.
