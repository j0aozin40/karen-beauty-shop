export type ProductCosts = {
  custo_aquisicao: number
  custo_adicional: number
  taxa_mp_percentual: number
  taxas_adicionais_percentual: number
  margem_desejada_percentual: number
}

export const MAX_PERCENTUAL = 99.99

export function precificacaoValida(values: ProductCosts) {
  const { custo_aquisicao, custo_adicional, taxa_mp_percentual, taxas_adicionais_percentual, margem_desejada_percentual } = values
  return [custo_aquisicao, custo_adicional, taxa_mp_percentual, taxas_adicionais_percentual, margem_desejada_percentual]
    .every(value => Number.isFinite(value) && value >= 0) &&
    [taxa_mp_percentual, taxas_adicionais_percentual, margem_desejada_percentual].every(value => value <= MAX_PERCENTUAL) &&
    taxa_mp_percentual + taxas_adicionais_percentual + margem_desejada_percentual < 100
}

export function calcularPreco(preco: number, costs: ProductCosts) {
  if (!precificacaoValida(costs)) return null
  const custoTotal = costs.custo_aquisicao + costs.custo_adicional
  const percentualLiquido = 1 - (costs.taxa_mp_percentual + costs.taxas_adicionais_percentual + costs.margem_desejada_percentual) / 100
  const sugerido = Math.round((custoTotal / percentualLiquido + Number.EPSILON) * 100) / 100
  const taxas = (costs.taxa_mp_percentual + costs.taxas_adicionais_percentual) / 100
  const lucro = preco * (1 - taxas) - custoTotal
  return { sugerido, lucro, margemReal: preco > 0 ? lucro / preco * 100 : 0 }
}
