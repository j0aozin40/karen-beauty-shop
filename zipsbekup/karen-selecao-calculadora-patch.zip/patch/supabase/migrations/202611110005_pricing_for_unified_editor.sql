-- Estrutura de salvamento único. Nenhum produto ou estoque é convertido durante a migration.
begin;

create or replace function public.excluir_variacao_segura(
  p_produto_id integer,
  p_id uuid,
  p_atualizado_em_original timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v public.produto_variacoes;
  controla boolean;
begin
  select controla_variacoes into controla
  from public.produtos where id = p_produto_id for update;
  if not found then raise exception 'Produto não encontrado.'; end if;

  select * into v from public.produto_variacoes
  where id = p_id and produto_id = p_produto_id for update;
  if not found then raise exception 'Variação não encontrada.'; end if;
  if p_atualizado_em_original is null
     or p_atualizado_em_original is distinct from v.atualizado_em then
    raise exception 'A variação mudou durante a edição. Atualize a lista antes de excluir.';
  end if;
  if controla and v.estoque <> 0 then
    raise exception 'Esta variação possui estoque. Desative-a para preservar as quantidades. Exclusão disponível somente com estoque zero.';
  end if;
  -- Gatilhos existentes bloqueiam exclusão com histórico, reservas ou da última opção convertida.
  delete from public.produto_variacoes where id = p_id and produto_id = p_produto_id;
  return jsonb_build_object('sucesso', true, 'id', p_id);
end;
$$;

revoke all on function public.excluir_variacao_segura(integer, uuid, timestamptz)
from public, anon, authenticated;
grant execute on function public.excluir_variacao_segura(integer, uuid, timestamptz)
to service_role;


create or replace function public.salvar_grupo_variacoes(
  p_produto_id integer,
  p_dados jsonb,
  p_variacoes jsonb,
  p_excluir jsonb,
  p_ajustar_estoque boolean
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  grupo public.produtos;
  atual public.produto_variacoes;
  entrada jsonb;
  excluida jsonb;
  registro jsonb;
  identificador uuid;
  total bigint;
  quantidade integer;
  novo boolean := p_produto_id is null;
  ativa boolean;
  sequencia text;
  novo_id bigint;
  custo_aq numeric;
  custo_add numeric;
  taxa_mp numeric;
  taxas_extra numeric;
  margem numeric;
begin
  if jsonb_typeof(p_variacoes) is distinct from 'array'
     or jsonb_array_length(p_variacoes) not between 1 and 50
     or jsonb_typeof(p_excluir) is distinct from 'array'
     or coalesce(length(btrim(p_dados->>'nome')),0) not between 1 and 160
     or coalesce(length(btrim(p_dados->>'categoria')),0) not between 1 and 80
     or coalesce(length(p_dados->>'descricao'),0) > 10000 then
    raise exception 'Confira os dados do produto e suas variações.';
  end if;
  if not exists (select 1 from public.categorias where nome=btrim(p_dados->>'categoria')) then
    raise exception 'Selecione uma categoria cadastrada.';
  end if;
  select count(*), coalesce(sum((v->>'estoque')::bigint),0), bool_or((v->>'ativo')::boolean)
  into quantidade, total, ativa from jsonb_array_elements(p_variacoes) v;
  if total < 0 or total > 2147483647 or ativa is null then
    raise exception 'Confira os estoques e a situação das variações.';
  end if;
  if exists (
    select 1 from (
      select v->>'id' as id from jsonb_array_elements(p_variacoes) v where v->>'id' is not null
      union all
      select v->>'id' from jsonb_array_elements(p_excluir) v
    ) ids group by id having count(*) > 1 or id is null
  ) then raise exception 'Variações repetidas ou inválidas na edição.'; end if;

  if novo then
    if jsonb_array_length(p_excluir) <> 0 or exists (select 1 from jsonb_array_elements(p_variacoes) v where v->>'id' is not null) then
      raise exception 'Um produto novo deve conter somente opções novas.';
    end if;
    -- Sequências antigas podem estar atrás dos IDs importados. Nunca reutiliza nem sobrescreve um cadastro.
    sequencia := coalesce(pg_get_serial_sequence('public.produtos','id'), to_regclass('public.produtos_id_seq')::text);
    if sequencia is null then raise exception 'A sequência de produtos precisa ser configurada.'; end if;
    loop
      novo_id := nextval(sequencia::regclass);
      if novo_id > 2147483647 then raise exception 'Limite de identificadores de produto atingido.'; end if;
      exit when not exists (select 1 from public.produtos where id=novo_id);
    end loop;
    insert into public.produtos(id,nome,categoria,descricao,preco,estoque,ativo,emoji,imagem)
    values(novo_id::integer,btrim(p_dados->>'nome'),btrim(p_dados->>'categoria'),coalesce(p_dados->>'descricao',''),
      (p_variacoes->0->>'preco')::numeric,total::integer,ativa,'🛍️',null)
    returning * into grupo;
    p_produto_id := grupo.id;
  else
    select * into grupo from public.produtos where id=p_produto_id for update;
    if not found then raise exception 'Produto não encontrado.'; end if;
    if p_dados->>'atualizado_em' is null
       or grupo.atualizado_em is distinct from (p_dados->>'atualizado_em')::timestamptz
       or grupo.estoque is distinct from (p_dados->>'estoque_original')::integer then
      raise exception 'O produto ou o estoque mudou durante a edição. Reabra o cadastro antes de salvar.';
    end if;
  end if;

  -- Confere todo o conjunto, inclusive exclusões, antes de qualquer alteração de opções.
  for atual in select * from public.produto_variacoes where produto_id=p_produto_id order by id for update loop
    select v into entrada from jsonb_array_elements(p_variacoes) v where v->>'id'=atual.id::text;
    select v into excluida from jsonb_array_elements(p_excluir) v where v->>'id'=atual.id::text;
    if entrada is null and excluida is null then
      raise exception 'A lista de variações mudou. Reabra o cadastro antes de salvar.';
    end if;
    registro := coalesce(entrada,excluida);
    if registro->>'atualizado_em' is null
       or atual.atualizado_em is distinct from (registro->>'atualizado_em')::timestamptz then
      raise exception 'Uma variação mudou durante a edição. Reabra o cadastro antes de salvar.';
    end if;
  end loop;
  if exists (
    select 1 from (
      select v from jsonb_array_elements(p_variacoes) v where v->>'id' is not null
      union all select v from jsonb_array_elements(p_excluir) v
    ) escolhidas
    where not exists (select 1 from public.produto_variacoes where id=(v->>'id')::uuid and produto_id=p_produto_id)
  ) then raise exception 'Uma opção não pertence a este produto.'; end if;

  if not grupo.controla_variacoes then
    if exists (
      select 1 from public.itens_pedido i join public.pedidos p on p.id=i.pedido_id
      where i.produto_id=p_produto_id and p.status='aguardando_pagamento' and not p.pedido_teste
    ) or exists (
      select 1 from public.reservas_estoque where produto_id=p_produto_id
      and variacao_id is null and status='reservada' and expira_em>now()
    ) then raise exception 'Produto possui pedidos ou reservas pendentes. Resolva-os antes de converter.'; end if;
    if total <> grupo.estoque and not coalesce(p_ajustar_estoque,false) then
      raise exception 'A soma das opções difere do estoque original. Confira e confirme o ajuste físico antes de salvar.';
    end if;
  end if;

  -- Os custos são compartilhados pelo produto e usados para sugerir o preço de cada opção.
  custo_aq := coalesce((p_dados->>'custo_aquisicao')::numeric, grupo.custo_aquisicao, 0);
  custo_add := coalesce((p_dados->>'custo_adicional')::numeric, grupo.custo_adicional, 0);
  taxa_mp := coalesce((p_dados->>'taxa_mp_percentual')::numeric, grupo.taxa_mp_percentual, 0);
  taxas_extra := coalesce((p_dados->>'taxas_adicionais_percentual')::numeric, grupo.taxas_adicionais_percentual, 0);
  margem := coalesce((p_dados->>'margem_desejada_percentual')::numeric, grupo.margem_desejada_percentual, case when novo then 30 else 0 end);
  if custo_aq not between 0 and 100000000 or custo_add not between 0 and 100000000
     or taxa_mp not between 0 and 99.99
     or taxas_extra not between 0 and 99.99
     or margem not between 0 and 99.99
     or taxa_mp + taxas_extra + margem >= 100 then
    raise exception 'As porcentagens devem ser de 0 a 99,99 por cento, e a soma das taxas e da margem precisa ficar abaixo de 100 por cento.';
  end if;
  -- O agrupamento deixa de escolher uma opção principal. Todas passam a ter a mesma função.
  update public.produtos set variacao_principal_id=null where id=p_produto_id;
  for entrada in select value from jsonb_array_elements(p_variacoes) loop
    identificador := (entrada->>'id')::uuid;
    registro := public.salvar_variacao(p_produto_id,identificador,
      entrada || jsonb_build_object('atualizado_em_original',entrada->>'atualizado_em'));
  end loop;
  for excluida in select value from jsonb_array_elements(p_excluir) loop
    -- As proteções existentes impedem apagar estoque convertido ou histórico.
    perform public.excluir_variacao_segura(p_produto_id,(excluida->>'id')::uuid,(excluida->>'atualizado_em')::timestamptz);
  end loop;
  select count(*), coalesce(sum(estoque),0) into quantidade,total
  from public.produto_variacoes where produto_id=p_produto_id;
  if quantidade < 1 then raise exception 'Mantenha pelo menos uma opção no cadastro.'; end if;
  if not grupo.controla_variacoes then
    -- A soma é conferida nesta transação, inclusive opções inativas.
    update public.produtos set estoque=total::integer where id=p_produto_id;
  end if;
  update public.produtos set
    nome=btrim(p_dados->>'nome'), categoria=btrim(p_dados->>'categoria'),
    descricao=coalesce(p_dados->>'descricao',''), imagem=null,
    custo_aquisicao=custo_aq, custo_adicional=custo_add, taxa_mp_percentual=taxa_mp,
    taxas_adicionais_percentual=taxas_extra, margem_desejada_percentual=margem,
    controla_variacoes=true, ativo=ativa, atualizado_em=now()
  where id=p_produto_id;

  return jsonb_build_object('id',p_produto_id,'variacoes',quantidade,'estoque',total,'sucesso',true);
end;
$$;
revoke all on function public.salvar_grupo_variacoes(integer,jsonb,jsonb,jsonb,boolean) from public,anon,authenticated;
grant execute on function public.salvar_grupo_variacoes(integer,jsonb,jsonb,jsonb,boolean) to service_role;

commit;
