-- Operação pontual autorizada: todos os pedidos existentes até 11/11/2026 05:42:51 UTC
-- foram identificados pelo usuário como desenvolvimento, inclusive os não marcados como teste.
-- Não é migration e não deve ser executada automaticamente em implantação.
-- Produtos, variações, estoque físico e sequências não são alterados.
begin;
set local lock_timeout = '5s';
set local statement_timeout = '60s';

create schema if not exists karen_backup_privado;
revoke all on schema karen_backup_privado from public, anon, authenticated, service_role;

create table if not exists karen_backup_privado.limpeza_pedidos_desenvolvimento (
  operacao text primary key,
  criado_em timestamptz not null default now(),
  limite_autorizado timestamptz not null,
  dados jsonb not null
);
alter table karen_backup_privado.limpeza_pedidos_desenvolvimento enable row level security;
revoke all on table karen_backup_privado.limpeza_pedidos_desenvolvimento
from public, anon, authenticated, service_role;

lock table public.pedidos, public.produtos, public.produto_variacoes,
  public.itens_pedido, public.reservas_estoque in share row exclusive mode;

do $$
declare
  codigo constant text := 'limpeza-desenvolvimento-20261111-054251';
  limite constant timestamptz := '2026-11-11 05:42:51+00';
  ids uuid[];
  estoque_antes jsonb;
  estoque_depois jsonb;
begin
  if exists (select 1 from karen_backup_privado.limpeza_pedidos_desenvolvimento where operacao = codigo) then
    raise notice 'Esta limpeza já foi executada. Nenhum novo pedido será removido.';
    return;
  end if;

  select coalesce(array_agg(id order by id), array[]::uuid[])
  into ids from public.pedidos where criado_em <= limite;

  select jsonb_build_object(
    'produtos', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'estoque', estoque, 'controla_variacoes', controla_variacoes) order by id), '[]'::jsonb) from public.produtos),
    'variacoes', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'produto_id', produto_id, 'estoque', estoque, 'ativo', ativo) order by id), '[]'::jsonb) from public.produto_variacoes)
  ) into estoque_antes;

  insert into karen_backup_privado.limpeza_pedidos_desenvolvimento (operacao, limite_autorizado, dados)
  select codigo, limite, jsonb_build_object(
    'motivo', 'Usuário confirmou que todos os pedidos existentes eram de desenvolvimento e autorizou excluir.',
    'pedidos', (select coalesce(jsonb_agg(to_jsonb(p) order by p.id), '[]'::jsonb) from public.pedidos p where p.id = any(ids)),
    'itens', (select coalesce(jsonb_agg(to_jsonb(i) order by i.id), '[]'::jsonb) from public.itens_pedido i where i.pedido_id = any(ids)),
    'reservas', (select coalesce(jsonb_agg(to_jsonb(r) order by r.id), '[]'::jsonb) from public.reservas_estoque r where r.pedido_id = any(ids)),
    'inventario_preservado', estoque_antes
  );

  update public.reservas_estoque
  set status = 'liberada', finalizado_em = now()
  where pedido_id = any(ids) and status = 'reservada';

  delete from public.reservas_estoque where pedido_id = any(ids);
  delete from public.itens_pedido where pedido_id = any(ids);
  delete from public.pedidos where id = any(ids);

  select jsonb_build_object(
    'produtos', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'estoque', estoque, 'controla_variacoes', controla_variacoes) order by id), '[]'::jsonb) from public.produtos),
    'variacoes', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'produto_id', produto_id, 'estoque', estoque, 'ativo', ativo) order by id), '[]'::jsonb) from public.produto_variacoes)
  ) into estoque_depois;
  if estoque_depois is distinct from estoque_antes then
    raise exception 'Limpeza cancelada: o inventário foi alterado. A transação será revertida.';
  end if;
end;
$$;

commit;

select
  operacao,
  jsonb_array_length(dados->'pedidos') as pedidos_excluidos,
  jsonb_array_length(dados->'itens') as itens_excluidos,
  jsonb_array_length(dados->'reservas') as reservas_excluidas,
  'Backup privado criado; estoque físico preservado' as resultado
from karen_backup_privado.limpeza_pedidos_desenvolvimento
where operacao = 'limpeza-desenvolvimento-20261111-054251';
