-- Define uma variação real como principal. Não cria opções nem altera estoques existentes.
begin;
alter table public.produtos add column if not exists variacao_principal_id uuid;
create unique index if not exists produto_variacoes_id_produto_principal_idx
  on public.produto_variacoes(id, produto_id);
do $$
begin
  if not exists (select 1 from pg_constraint where conname='produtos_variacao_principal_mesmo_produto_fk' and conrelid='public.produtos'::regclass) then
    alter table public.produtos add constraint produtos_variacao_principal_mesmo_produto_fk
      foreign key (variacao_principal_id, id) references public.produto_variacoes(id, produto_id);
  end if;
end;
$$;

create or replace function public.proteger_opcao_principal()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if TG_OP = 'DELETE' or (TG_OP = 'UPDATE' and NEW.ativo = false) then
    if exists (select 1 from public.produtos where variacao_principal_id=OLD.id) then
      raise exception 'Defina outra opção principal na aba Geral antes de desativar ou excluir esta opção.';
    end if;
  end if;
  if TG_OP = 'DELETE' then return OLD; end if;
  return NEW;
end;
$$;
revoke all on function public.proteger_opcao_principal() from public,anon,authenticated;
drop trigger if exists proteger_opcao_principal on public.produto_variacoes;
create trigger proteger_opcao_principal before update or delete on public.produto_variacoes
for each row execute function public.proteger_opcao_principal();

create or replace function public.salvar_variacao_principal(
  p_produto_id integer,
  p_variacao_id uuid,
  p_dados jsonb,
  p_atualizado_em_original timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  p public.produtos;
  v public.produto_variacoes;
  criada jsonb;
begin
  select * into p from public.produtos where id=p_produto_id for update;
  if not found then raise exception 'Produto não encontrado.'; end if;
  if p_atualizado_em_original is null or p.atualizado_em is distinct from p_atualizado_em_original then
    raise exception 'O produto mudou. Atualize os dados antes de definir a opção principal.';
  end if;
  if p_variacao_id is null then
    if p_dados is null or coalesce((p_dados->>'ativo')::boolean,false) = false then
      raise exception 'Cadastre uma opção principal ativa.';
    end if;
    criada := public.salvar_variacao(p_produto_id,null,p_dados);
    p_variacao_id := (criada->>'id')::uuid;
  end if;
  select * into v from public.produto_variacoes
    where id=p_variacao_id and produto_id=p_produto_id for update;
  if not found then raise exception 'A opção principal deve pertencer a este produto.'; end if;
  if not v.ativo then raise exception 'Ative a opção antes de defini-la como principal.'; end if;
  update public.produtos set variacao_principal_id=v.id, atualizado_em=now() where id=p_produto_id;
  return jsonb_build_object('sucesso',true,'variacao_principal_id',v.id,'variacao',to_jsonb(v));
end;
$$;
revoke all on function public.salvar_variacao_principal(integer,uuid,jsonb,timestamptz) from public,anon,authenticated;
grant execute on function public.salvar_variacao_principal(integer,uuid,jsonb,timestamptz) to service_role;

create or replace function public.catalogo_disponivel()
returns jsonb language sql security definer set search_path='' as $$
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',p.id,'name',p.nome,'category',p.categoria,'price',coalesce((select coalesce(v.preco_promocional,v.preco) from public.produto_variacoes v where v.id=p.variacao_principal_id and v.produto_id=p.id and v.ativo and p.controla_variacoes),p.preco),'description',p.descricao,'emoji',p.emoji,'imagem',coalesce((select v.imagem from public.produto_variacoes v where v.id=p.variacao_principal_id and v.produto_id=p.id and v.ativo and p.controla_variacoes),p.imagem),
    'controla_variacoes',p.controla_variacoes,
    'variacao_principal_id',case when p.controla_variacoes and exists(select 1 from public.produto_variacoes v where v.id=p.variacao_principal_id and v.produto_id=p.id and v.ativo) then p.variacao_principal_id else null end,
    'stock',case when p.controla_variacoes then
      (select coalesce(sum(greatest(v.estoque-coalesce((select sum(r.quantidade) from public.reservas_estoque r
        where r.variacao_id=v.id and r.status='reservada' and r.expira_em>now()),0),0)),0)
       from public.produto_variacoes v where v.produto_id=p.id and v.ativo)
      else greatest(p.estoque-coalesce((select sum(r.quantidade) from public.reservas_estoque r
        where r.produto_id=p.id and r.variacao_id is null and r.status='reservada' and r.expira_em>now()),0),0) end,
    'variacoes',case when p.controla_variacoes then
      (select coalesce(jsonb_agg(jsonb_build_object('id',v.id,'tipo',v.tipo,'nome',v.nome,'sku',v.sku,'imagem',v.imagem,
        'price',coalesce(v.preco_promocional,v.preco,p.preco),'stock',greatest(v.estoque-coalesce((select sum(r.quantidade)
          from public.reservas_estoque r where r.variacao_id=v.id and r.status='reservada' and r.expira_em>now()),0),0)) order by (v.id=p.variacao_principal_id) desc nulls last,v.nome),'[]'::jsonb)
       from public.produto_variacoes v where v.produto_id=p.id and v.ativo)
      else '[]'::jsonb end) order by p.id),'[]'::jsonb) from public.produtos p where p.ativo;
$$;
revoke all on function public.catalogo_disponivel() from public, anon, authenticated;
grant execute on function public.catalogo_disponivel() to service_role;

commit;
