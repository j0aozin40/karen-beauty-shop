# Opção principal como variação real

## Comportamento
O produto original passa a ser representado por uma opção real, do mesmo conjunto das outras variações. A opção principal pode ter qualquer tipo disponível: cor, tamanho, fragrância, acabamento, kit ou outro. Tem nome, SKU, estoque, preço opcional, promoção e foto próprios.

Em Produtos → Editar → Geral, a seção Opção principal permite:
- Escolher uma variação existente e defini-la como principal, sem criar outro registro ou copiar estoque.
- Cadastrar a opção original, informando seus dados físicos. O estoque inicial sugerido é zero; o total do produto nunca é copiado automaticamente.
- Editar a opção principal na própria aba Geral, usando a proteção contra edições antigas.

No site, a principal aparece na mesma lista de opções e recebe a identificação Principal. É a seleção inicial quando estiver configurada e pode ser escolhida novamente após qualquer outra opção. Foto, preço, estoque, carrinho, reserva e checkout usam o ID real dessa variação. A solução anterior de miniaturas e Limpar seleção foi substituída conforme solicitado.

## Estoque
Definir uma opção existente como principal não muda nenhuma quantidade. Ao cadastrar uma opção nova, informe SOMENTE as unidades físicas dela; não replique o estoque agregado. Em um produto já convertido, o estoque total continua sendo a soma das opções. Em um produto ainda não convertido, as opções são rascunhos até conferir o total e usar Ativar variações no catálogo.

A opção principal não pode ser desativada ou excluída enquanto estiver nessa função. Primeiro defina outra principal na aba Geral. As demais proteções de histórico, reservas e estoque continuam.

A foto de exemplo da Henna não foi convertida automaticamente em uma cor ou estoque. Nenhuma variação foi criada ou renomeada no banco real.

## Instalar os arquivos
Envie `karen-opcao-principal-patch.zip` para `/workspaces/karen-beauty-shop` no Codespaces e execute:

```bash
PASTA_PATCH="$(mktemp -d /workspaces/karen-principal-XXXXXX)"
unzip -n /workspaces/karen-beauty-shop/karen-opcao-principal-patch.zip -d "$PASTA_PATCH" &&
node "$PASTA_PATCH/aplicar-opcao-principal.mjs" /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
```

O instalador aceita os arquivos da interface v2, com ou sem os patches de limpeza e galeria. Faz backup e para antes de gravar se encontrar mudanças locais desconhecidas. Preserva as configurações. Não executa SQL nem altera dados remotos. A remoção da seção Pedidos de teste permanece no painel.

## Atualização de banco necessária
`supabase/migrations/202611110003_primary_variation.sql` adiciona a identificação da opção principal, com vínculo ao mesmo produto, a função administrativa para defini-la e sua presença no catálogo público. Não cria variações nem redistribui estoques existentes. Inclui a proteção para trocar a principal antes de excluir/desativar.

A migration está pronta, mas NÃO foi aplicada ao Supabase. A aplicação depende de autorização do usuário. Use o arquivo completo em uma nova consulta do SQL Editor somente após essa autorização. Não reaplique migrations antigas nem o SQL de exclusão de pedidos.

Após aplicação autorizada, confira:

```sql
select
  exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='produtos'
      and column_name='variacao_principal_id'
  ) as coluna_principal_instalada,
  to_regprocedure('public.salvar_variacao_principal(integer,uuid,jsonb,timestamp with time zone)') is not null
    as funcao_principal_instalada;
```

## Iniciar e usar
Valide os arquivos:

```bash
cd /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
npm test && npm run build
```

Reinicie a API e o site nessa pasta. Mantenha o túnel do Windows rodando e atualize a página com Ctrl+Shift+R. Após instalar a migration, configure a opção principal em Geral. Para um produto novo, cadastre primeiro e reabra a edição para cadastrar a opção original.

Cada opção é uma unidade de estoque vendável. Combinações como Rosa/M e Rosa/G precisam de opções próprias; não são geradas combinações automáticas entre os tipos.

## Verificação
33 testes aprovados: proteção de estoque, variação principal existente sem duplicação, criação explícita com saldo zero, seleção de outro produto rejeitada, concorrência, segurança de permissões, catálogo, reserva e pagamento com ID da principal. TypeScript e build aprovados. Verificação no navegador com dados fictícios confirmou Geral, cadastro/edição de tipos, troca entre opção principal e outra opção, foto e carrinho, além do layout de celular. Nenhum dado remoto foi alterado nesta tarefa.
