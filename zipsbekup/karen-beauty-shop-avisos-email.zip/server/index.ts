
import express from 'express'
import session from 'express-session'
import { timingSafeEqual } from 'node:crypto'
import cors from 'cors'
import dotenv from 'dotenv'
import { createClient } from '@supabase/supabase-js'
import nodemailer from 'nodemailer'
import { products } from '../src/products.ts'
import { randomUUID } from 'node:crypto'

declare module 'express-session' {
  interface SessionData {
    admin: boolean
  }
}

dotenv.config({ path: '.env.local' })

const app = express()
const PORT = process.env.PORT || 3001

app.use(cors())
app.use(express.json({ limit: '20kb' }))

app.use(session({
  name: 'karen_admin_session',
  secret: process.env.ADMIN_SESSION_SECRET!,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    maxAge: 8 * 60 * 60 * 1000
  }
}))

const supabaseUrl = process.env.VITE_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SECRET_KEY

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Configure as variáveis do Supabase.')
}

const supabase = createClient(supabaseUrl, supabaseKey)
const PHOTO_BUCKET = process.env.PRODUCT_PHOTO_BUCKET || 'product-photos'
const configuredAdminPassword = process.env.ADMIN_PASSWORD

if (!configuredAdminPassword) {
  throw new Error('Configure a senha administrativa.')
}
const adminPassword: string = configuredAdminPassword

function senhaValida(senha: string) {
  const recebida = Buffer.from(senha)
  const cadastrada = Buffer.from(adminPassword)

  return recebida.length === cadastrada.length &&
    timingSafeEqual(recebida, cadastrada)
}

function requireAdmin(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) {
  if (req.session.admin === true) {
    return next()
  }

  return res.status(401).json({
    erro: 'Acesso administrativo não autorizado.'
  })
}

function escaparHtml(valor: string | number) {
  const entidades: Record<string, string> = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }
  return String(valor).replace(/[&<>"']/g, caractere => entidades[caractere])
}

function money(valor: number) {
  return Number(valor).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}

type DadosEmailPedido = {
  numero: string | number
  nome: string
  email: string
  whatsapp: string
  tipoEntrega: string
  enderecoCompleto: string
  total: number
  itens: Array<{ nome_produto: string; quantidade: number; preco_unitario: number; total_item: number }>
}

async function enviarEmailsPedido(pedido: DadosEmailPedido) {
  const smtpHost = process.env.SMTP_HOST
  const smtpUser = process.env.SMTP_USER
  const smtpPass = process.env.SMTP_PASS
  const fromEmail = process.env.SMTP_FROM_EMAIL || smtpUser
  const emailLoja = process.env.ORDER_NOTIFICATION_EMAIL || smtpUser
  const smtpPort = Number(process.env.SMTP_PORT || 587)

  if (!smtpHost || !smtpUser || !smtpPass || !fromEmail || !emailLoja) {
    console.warn('Notificações de pedido por e-mail não enviadas: configure SMTP_HOST, SMTP_USER, SMTP_PASS e ORDER_NOTIFICATION_EMAIL no ambiente do servidor.')
    return { cliente: false, loja: false }
  }

  const transportador = nodemailer.createTransport({
    host: smtpHost,
    port: smtpPort,
    secure: smtpPort === 465,
    auth: { user: smtpUser, pass: smtpPass.replace(/\s/g, '') },
  })
  const itensTexto = pedido.itens.map(item => `${item.quantidade} x ${item.nome_produto} — ${money(item.total_item)}`).join('\n')
  const itensHtml = pedido.itens.map(item => `<li>${item.quantidade} × ${escaparHtml(item.nome_produto)} — ${money(item.total_item)}</li>`).join('')
  const cabecalhoHtml = `<h2>Pedido nº ${escaparHtml(pedido.numero)}</h2><p><strong>Cliente:</strong> ${escaparHtml(pedido.nome)}</p><p><strong>WhatsApp:</strong> ${escaparHtml(pedido.whatsapp)}</p><p><strong>Entrega:</strong> ${escaparHtml(pedido.tipoEntrega === 'pickup' ? 'Retirada na loja' : 'Entrega no endereço')}</p>${pedido.enderecoCompleto ? `<p><strong>Endereço:</strong> ${escaparHtml(pedido.enderecoCompleto)}</p>` : ''}<ul>${itensHtml}</ul><p><strong>Total: ${money(pedido.total)}</strong></p>`
  const remetente = `Karen Beauty Shop <${fromEmail}>`

  const [resultadoCliente, resultadoLoja] = await Promise.allSettled([
    transportador.sendMail({
      from: remetente,
      to: pedido.email,
      subject: `Recebemos seu pedido nº ${pedido.numero} | Karen Beauty Shop`,
      text: `Olá, ${pedido.nome}! Recebemos seu pedido nº ${pedido.numero}.\n\n${itensTexto}\n\nTotal: ${money(pedido.total)}\nEntrega: ${pedido.tipoEntrega === 'pickup' ? 'Retirada na loja' : 'Entrega no endereço'}\n\nA loja entrará em contato para confirmar os próximos passos.`,
      html: `<p>Olá, ${escaparHtml(pedido.nome)}! Recebemos seu pedido.</p>${cabecalhoHtml}<p>A loja entrará em contato para confirmar os próximos passos.</p>`,
    }),
    transportador.sendMail({
      from: remetente,
      to: emailLoja,
      replyTo: pedido.email,
      subject: `Novo pedido nº ${pedido.numero} | Karen Beauty Shop`,
      text: `Novo pedido nº ${pedido.numero}\nCliente: ${pedido.nome}\nE-mail: ${pedido.email}\nWhatsApp: ${pedido.whatsapp}\nEntrega: ${pedido.tipoEntrega === 'pickup' ? 'Retirada na loja' : 'Entrega no endereço'}\n${pedido.enderecoCompleto ? `Endereço: ${pedido.enderecoCompleto}\n` : ''}\n${itensTexto}\n\nTotal: ${money(pedido.total)}`,
      html: `<p>Novo pedido recebido.</p>${cabecalhoHtml}<p><strong>E-mail do cliente:</strong> ${escaparHtml(pedido.email)}</p>`,
    }),
  ])

  if (resultadoCliente.status === 'rejected') console.error('Falha ao enviar confirmação ao cliente:', resultadoCliente.reason instanceof Error ? resultadoCliente.reason.message : 'erro SMTP')
  if (resultadoLoja.status === 'rejected') console.error('Falha ao enviar aviso à loja:', resultadoLoja.reason instanceof Error ? resultadoLoja.reason.message : 'erro SMTP')
  return {
    cliente: resultadoCliente.status === 'fulfilled',
    loja: resultadoLoja.status === 'fulfilled',
  }
}
app.post('/api/admin/login', (req, res) => {
  const { senha } = req.body

  if (typeof senha !== 'string' || !senhaValida(senha)) {
    return res.status(401).json({
      erro: 'Senha administrativa incorreta.'
    })
  }

  req.session.regenerate((error) => {
    if (error) {
      return res.status(500).json({
        erro: 'Não foi possível iniciar a sessão.'
      })
    }

    req.session.admin = true

    req.session.save((saveError) => {
      if (saveError) {
        return res.status(500).json({
          erro: 'Não foi possível salvar a sessão.'
        })
      }

      return res.json({
        mensagem: 'Login realizado com sucesso!'
      })
    })
  })
})

app.get('/api/admin/me', requireAdmin, (_req, res) => {
  res.json({ autenticado: true })
})

app.post('/api/admin/logout', requireAdmin, (req, res) => {
  req.session.destroy((error) => {
    if (error) {
      return res.status(500).json({
        erro: 'Não foi possível encerrar a sessão.'
      })
    }

    res.clearCookie('karen_admin_session')
    return res.json({ mensagem: 'Logout realizado.' })
  })
})
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    message: 'Servidor Karen Beauty Shop funcionando!'
  })
})

app.get('/api/produtos', async (_req, res) => {
  const { data, error } = await supabase.from('produtos').select('id,nome,categoria,preco,descricao,emoji,estoque,imagem').eq('ativo', true).order('id')
  if (error) return res.status(500).json({ erro: 'Não foi possível carregar o catálogo.' })
  return res.json({ produtos: (data || []).map(p => ({ id: p.id, name: p.nome, category: p.categoria, price: Number(p.preco), description: p.descricao || '', emoji: p.emoji || '🛍️', stock: Number(p.estoque), imagem: p.imagem })) })
})

async function clienteAutenticado(req: express.Request) {
  const authorization = req.get('authorization')
  const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1]
  if (!token) return null
  const { data, error } = await supabase.auth.getUser(token)
  if (error || !data.user) return null
  return data.user
}

app.get('/api/me/pedidos', async (req, res) => {
  try {
    const cliente = await clienteAutenticado(req)
    if (!cliente) return res.status(401).json({ erro: 'Entre na sua conta para consultar os pedidos.' })
    const { data, error } = await supabase
      .from('pedidos')
      .select('id,numero_pedido,total,status,criado_em,itens_pedido(id,nome_produto,quantidade,total_item)')
      .eq('cliente_id', cliente.id)
      .order('criado_em', { ascending: false })
    if (error) throw error
    return res.json({ pedidos: data || [] })
  } catch (error) {
    console.error('Erro ao carregar pedidos do cliente:', error)
    return res.status(500).json({ erro: 'Não foi possível carregar seus pedidos.' })
  }
})

app.post('/api/pedidos', async (req, res) => {
  try {
    const authorization = req.get('authorization')
    let clienteId: string | null = null
    if (authorization) {
      const cliente = await clienteAutenticado(req)
      if (!cliente) return res.status(401).json({ erro: 'Sua sessão expirou. Entre novamente para registrar o pedido na conta.' })
      clienteId = cliente.id
    }
    const {
      nome,
      whatsapp,
      email,
      tipo_entrega,
      cep,
      cidade,
      estado,
      endereco,
      numero,
      complemento,
      bairro,
      itens
    } = req.body

    if (
      typeof nome !== 'string' || !nome.trim() ||
      typeof whatsapp !== 'string' || !whatsapp.trim() ||
      typeof email !== 'string' ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
      !['delivery', 'pickup'].includes(tipo_entrega) ||
      !Array.isArray(itens) ||
      itens.length === 0 ||
      itens.length > 50
    ) {
      return res.status(400).json({
        erro: 'Confira os dados do pedido.'
      })
    }

    if (tipo_entrega === 'delivery' && (
      !cidade || !estado || !endereco || !numero || !bairro
    )) {
      return res.status(400).json({
        erro: 'Preencha o endereço de entrega.'
      })
    }

    let subtotal = 0
    const itensValidados = []

    for (const item of itens) {
      const { data: produto } = await supabase.from('produtos').select('id,nome,preco,estoque,ativo').eq('id', Number(item.produto_id)).eq('ativo', true).maybeSingle()

      const quantidade = Number(item.quantidade)

      if (
        !produto ||
        !Number.isInteger(quantidade) ||
        quantidade < 1 ||
        quantidade > Number(produto.estoque)
      ) {
        return res.status(400).json({
          erro: 'Produto ou quantidade inválida.'
        })
      }

      const totalItem = Number(produto.preco) * quantidade
      subtotal += totalItem

      itensValidados.push({
        produto_id: produto.id,
        nome_produto: produto.nome,
        quantidade,
        preco_unitario: Number(produto.preco),
        total_item: totalItem
      })
    }

    const { data: pedido, error: erroPedido } = await supabase
      .from('pedidos')
      .insert({
        nome: nome.trim(),
        whatsapp: whatsapp.trim(),
        email: email.trim().toLowerCase(),
        tipo_entrega,
        cep: cep || null,
        cidade: cidade || null,
        estado: estado || null,
        endereco: endereco || null,
        numero: numero || null,
        complemento: complemento || null,
        bairro: bairro || null,
        cliente_id: clienteId,
        subtotal,
        frete: 0,
        total: subtotal,
        status: 'aguardando_pagamento'
      })
      .select('id, numero_pedido')
      .single()

    if (erroPedido || !pedido) {
      console.error('Erro ao criar pedido:', erroPedido)
      return res.status(500).json({
        erro: 'Não foi possível registrar o pedido.'
      })
    }

    const itensComPedido = itensValidados.map(item => ({
      ...item,
      pedido_id: pedido.id
    }))

    const { error: erroItens } = await supabase
      .from('itens_pedido')
      .insert(itensComPedido)

    if (erroItens) {
      console.error('Erro ao salvar itens:', erroItens)

      await supabase
        .from('pedidos')
        .delete()
        .eq('id', pedido.id)

      return res.status(500).json({
        erro: 'Não foi possível registrar os itens do pedido.'
      })
    }

    const enderecoCompleto = tipo_entrega === 'delivery'
      ? [endereco, numero, complemento, bairro, cidade, estado, cep].filter(Boolean).join(', ')
      : ''
    const emailsEnviados = await enviarEmailsPedido({
      numero: pedido.numero_pedido,
      nome: nome.trim(),
      email: email.trim().toLowerCase(),
      whatsapp: whatsapp.trim(),
      tipoEntrega: tipo_entrega,
      enderecoCompleto,
      total: subtotal,
      itens: itensValidados,
    })

    return res.status(201).json({
      mensagem: 'Pedido registrado com sucesso!',
      pedido: {
        id: pedido.id,
        numero: pedido.numero_pedido,
        total: subtotal,
        status: 'aguardando_pagamento'
      },
      emails: emailsEnviados,
    })
  } catch (error) {
    console.error('Erro inesperado:', error)

    return res.status(500).json({
      erro: 'Ocorreu um erro ao processar o pedido.'
    })
  }
})
app.get('/api/admin/dashboard', requireAdmin, async (_req, res) => {
  try {
    const { data: pedidos, error } = await supabase
      .from('pedidos')
      .select(`
        id,
        numero_pedido,
        nome,
        whatsapp,
        total,
        status,
        criado_em
      `)
      .order('criado_em', { ascending: false })

    if (error) {
      console.error('Erro ao buscar pedidos:', error)
      return res.status(500).json({
        erro: 'Não foi possível carregar os pedidos.'
      })
    }

    const lista = pedidos || []

    const valorTotal = lista.reduce(
      (soma, pedido) => soma + Number(pedido.total || 0),
      0
    )

    return res.json({
      resumo: {
        quantidadePedidos: lista.length,
        valorTotal,
        pedidosAguardando: lista.filter(
          pedido => pedido.status === 'aguardando_pagamento'
        ).length,
        pedidosConcluidos: lista.filter(
          pedido => pedido.status === 'concluido'
        ).length
      },
      pedidosRecentes: lista.slice(0, 10)
    })
  } catch (error) {
    console.error('Erro no dashboard:', error)
    return res.status(500).json({
      erro: 'Erro ao carregar o dashboard.'
    })
  }
})
app.patch('/api/admin/pedidos/:id/status', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params
    const { status } = req.body

    const statusPermitidos = [
      'aguardando_pagamento',
      'confirmado',
      'preparando',
      'enviado',
      'concluido'
    ]

    if (!statusPermitidos.includes(status)) {
      return res.status(400).json({
        erro: 'Status inválido.'
      })
    }

    const { data, error } = await supabase
      .from('pedidos')
      .update({ status })
      .eq('id', id)
      .select('id, numero_pedido, status')
      .single()

    if (error || !data) {
      console.error('Erro ao atualizar pedido:', error)

      return res.status(500).json({
        erro: 'Não foi possível atualizar o pedido.'
      })
    }

    return res.json({
      mensagem: 'Status atualizado com sucesso!',
      pedido: data
    })
  } catch (error) {
    console.error('Erro ao atualizar status:', error)

    return res.status(500).json({
      erro: 'Erro inesperado ao atualizar o pedido.'
    })
  }
})
app.get('/api/admin/pedidos/:id', requireAdmin, async (req, res) => {
  try {
    const { data: pedido, error } = await supabase
      .from('pedidos')
      .select(`
        *,
        itens_pedido (*)
      `)
      .eq('id', req.params.id)
      .single()

    if (error) {
      return res.status(404).json({
        erro: 'Pedido não encontrado.',
      })
    }

    return res.json({ pedido })
  } catch (error) {
    console.error('Erro ao buscar detalhes do pedido:', error)

    return res.status(500).json({
      erro: 'Não foi possível carregar os detalhes do pedido.',
    })
  }
})
app.post('/api/admin/produtos/importar', requireAdmin, async (_req, res) => {
  try {
    const lista = products.map((produto) => ({
      id: produto.id,
      nome: produto.name,
      categoria: produto.category,
      preco: produto.price,
      descricao: produto.description,
      emoji: produto.emoji,
      estoque: produto.stock,
      ativo: true,
    }))

    const { error } = await supabase
      .from('produtos')
      .upsert(lista, { onConflict: 'id' })

    if (error) throw error

    return res.json({
      mensagem: 'Catálogo importado com sucesso!',
      quantidade: lista.length,
    })
  } catch (error) {
    console.error('Erro ao importar produtos:', error)

    return res.status(500).json({
      erro: 'Não foi possível importar os produtos.',
    })
  }
})
app.get('/api/admin/produtos', requireAdmin, async (_req, res) => {
  try {
    const { data, error } = await supabase
      .from('produtos')
      .select('*')
      .order('id', { ascending: true })

        if (error) throw error

    return res.json({ produtos: data })
  } catch (error) {
    console.error('Erro ao listar produtos:', error)

    return res.status(500).json({
      erro: 'Não foi possível carregar os produtos.',
    })
  }
})

app.post('/api/admin/produtos', requireAdmin, async (req, res) => {
  try {
    const { nome, categoria, preco, descricao, emoji, estoque, ativo } = req.body
    const nomeProduto = typeof nome === 'string' ? nome.trim() : ''
    const nomeCategoria = typeof categoria === 'string' ? categoria.trim() : ''
    if (!nomeProduto || !nomeCategoria || nomeProduto.length > 160 || !Number.isFinite(Number(preco)) || Number(preco) < 0 || !Number.isInteger(Number(estoque)) || Number(estoque) < 0 || typeof ativo !== 'boolean') {
      return res.status(400).json({ erro: 'Confira os dados do produto.' })
    }
    const { data: categoriaEncontrada, error: erroCategoria } = await supabase.from('categorias').select('id').eq('nome', nomeCategoria).maybeSingle()
    if (erroCategoria || !categoriaEncontrada) return res.status(400).json({ erro: 'Selecione uma categoria cadastrada.' })
    const { data, error } = await supabase.from('produtos').insert({
      nome: nomeProduto, categoria: nomeCategoria, preco: Number(preco), descricao: descricao || '',
      emoji: emoji || '🛍️', estoque: Number(estoque), ativo, imagem: null,
      criado_em: new Date().toISOString(), atualizado_em: new Date().toISOString(),
    }).select().single()
    if (error) throw error
    return res.status(201).json({ produto: data })
  } catch (error) {
    console.error('Erro ao cadastrar produto:', error)
    return res.status(500).json({ erro: 'Não foi possível cadastrar o produto.' })
  }
})

app.delete('/api/admin/produtos/:id', requireAdmin, async (req, res) => {
  try {
    const id = Number(req.params.id)
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ erro: 'Produto inválido.' })
    const { count, error: erroItens } = await supabase.from('itens_pedido').select('id', { count: 'exact', head: true }).eq('produto_id', id)
    if (erroItens) throw erroItens
    if ((count || 0) > 0) return res.status(409).json({ erro: 'Este produto tem histórico de pedidos. Desative-o em vez de excluí-lo.' })
    const { data: produto, error: erroBusca } = await supabase.from('produtos').select('imagem').eq('id', id).maybeSingle()
    if (erroBusca) throw erroBusca
    if (!produto) return res.status(404).json({ erro: 'Produto não encontrado.' })
    const { error } = await supabase.from('produtos').delete().eq('id', id)
    if (error) throw error
    const path = produto.imagem ? caminhoFotoDoBucket(produto.imagem) : null
    if (path) {
      const { error: erroFoto } = await supabase.storage.from(PHOTO_BUCKET).remove([path])
      if (erroFoto) console.error('Não foi possível remover a foto do produto excluído:', erroFoto.message)
    }
    return res.json({ mensagem: 'Produto excluído.' })
  } catch (error) {
    console.error('Erro ao excluir produto:', error)
    return res.status(500).json({ erro: 'Não foi possível excluir o produto.' })
  }
})

function caminhoFotoDoBucket(url: string) {
  const marker = `/storage/v1/object/public/${PHOTO_BUCKET}/`
  const index = url.indexOf(marker)
  if (index < 0) return null
  try { return decodeURIComponent(url.slice(index + marker.length).split('?')[0]) } catch { return null }
}

app.get('/api/admin/categorias', requireAdmin, async (_req, res) => {
  const { data, error } = await supabase.from('categorias').select('id,nome').order('nome')
  if (error) return res.status(500).json({ erro: 'Não foi possível carregar categorias.' })
  return res.json({ categorias: data || [] })
})

app.post('/api/admin/categorias', requireAdmin, async (req, res) => {
  const nome = typeof req.body?.nome === 'string' ? req.body.nome.trim() : ''
  if (!nome || nome.length > 80) return res.status(400).json({ erro: 'Informe um nome de até 80 caracteres.' })
  const { data, error } = await supabase.from('categorias').insert({ nome }).select('id,nome').single()
  if (error) return res.status(409).json({ erro: 'Não foi possível criar a categoria; verifique se o nome já existe.' })
  return res.status(201).json({ categoria: data })
})

app.patch('/api/admin/categorias/:id', requireAdmin, async (req, res) => {
  const nome = typeof req.body?.nome === 'string' ? req.body.nome.trim() : ''
  if (!nome || nome.length > 80) return res.status(400).json({ erro: 'Informe um nome de até 80 caracteres.' })
  const { data, error } = await supabase.rpc('renomear_categoria', { categoria_id: req.params.id, novo_nome: nome })
  if (error) return res.status(409).json({ erro: 'Não foi possível renomear a categoria.' })
  return res.json({ categoria: data })
})

app.delete('/api/admin/categorias/:id', requireAdmin, async (req, res) => {
  const { data, error } = await supabase.rpc('excluir_categoria', { categoria_id: req.params.id })
  if (error || data === false) return res.status(409).json({ erro: 'A categoria pode estar em uso por produtos e não foi excluída.' })
  return res.json({ mensagem: 'Categoria excluída.' })
})

app.put('/api/admin/produtos/:id/foto', requireAdmin, express.raw({ type: ['image/jpeg', 'image/png', 'image/webp'], limit: '5mb' }), async (req, res) => {
  const id = Number(req.params.id)
  const mime = req.headers['content-type']
  const ext = mime === 'image/jpeg' ? 'jpg' : mime === 'image/png' ? 'png' : mime === 'image/webp' ? 'webp' : ''
  if (!Number.isSafeInteger(id) || id < 1 || !ext || !Buffer.isBuffer(req.body) || req.body.length === 0) return res.status(400).json({ erro: 'Envie uma imagem JPG, PNG ou WebP de até 5 MB.' })
  const { data: produto, error: erroBusca } = await supabase.from('produtos').select('imagem').eq('id', id).maybeSingle()
  if (erroBusca) return res.status(500).json({ erro: 'Não foi possível localizar o produto.' })
  if (!produto) return res.status(404).json({ erro: 'Produto não encontrado.' })
  const path = `${id}/${randomUUID()}.${ext}`
  const { error: uploadError } = await supabase.storage.from(PHOTO_BUCKET).upload(path, req.body, { contentType: mime, upsert: false })
  if (uploadError) return res.status(500).json({ erro: 'Não foi possível enviar a foto.' })
  const { data: urlData } = supabase.storage.from(PHOTO_BUCKET).getPublicUrl(path)
  const { data: produtoAtualizado, error: updateError } = await supabase.from('produtos').update({ imagem: urlData.publicUrl }).eq('id', id).select('id').maybeSingle()
  if (updateError || !produtoAtualizado) {
    await supabase.storage.from(PHOTO_BUCKET).remove([path])
    if (updateError) console.error('Erro ao vincular foto:', updateError.code, updateError.message)
    return res.status(500).json({ erro: 'Não foi possível vincular a foto ao produto.' })
  }
  const fotoAnterior = produto.imagem ? caminhoFotoDoBucket(produto.imagem) : null
  if (fotoAnterior) {
    const { error: erroFotoAnterior } = await supabase.storage.from(PHOTO_BUCKET).remove([fotoAnterior])
    if (erroFotoAnterior) console.error('Foto atualizada, mas a foto anterior não foi removida:', erroFotoAnterior.message)
  }
  return res.json({ imagem: urlData.publicUrl })
})

app.delete('/api/admin/produtos/:id/foto', requireAdmin, async (req, res) => {
  const id = Number(req.params.id)
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ erro: 'Produto inválido.' })
  const { data: produto, error: erroBusca } = await supabase.from('produtos').select('imagem').eq('id', id).maybeSingle()
  if (erroBusca) return res.status(500).json({ erro: 'Não foi possível localizar a foto.' })
  if (!produto) return res.status(404).json({ erro: 'Produto não encontrado.' })
  const { error } = await supabase.from('produtos').update({ imagem: null }).eq('id', id)
  if (error) return res.status(500).json({ erro: 'Não foi possível desvincular a foto do produto.' })
  const path = produto.imagem ? caminhoFotoDoBucket(produto.imagem) : null
  if (path) {
    const { error: erroFoto } = await supabase.storage.from(PHOTO_BUCKET).remove([path])
    if (erroFoto) console.error('Foto desvinculada, mas não foi removida do Storage:', erroFoto.message)
  }
  return res.json({ mensagem: 'Foto removida.', imagem: null })
})

app.patch('/api/admin/produtos/:id', requireAdmin, async (req, res) => {
  try {
    const id = Number(req.params.id)
    const { nome, categoria, preco, descricao, emoji, estoque, ativo } = req.body

    if (
      !Number.isInteger(id) ||
      !nome?.trim() ||
      !categoria?.trim() ||
      !Number.isFinite(Number(preco)) ||
      Number(preco) < 0 ||
      !Number.isInteger(Number(estoque)) ||
      Number(estoque) < 0 ||
      typeof ativo !== 'boolean'
    ) {
      return res.status(400).json({
        erro: 'Confira os dados do produto.',
      })
    }

    const { data, error } = await supabase
      .from('produtos')
      .update({
        nome: nome.trim(),
        categoria: categoria.trim(),
        preco: Number(preco),
        descricao: descricao || '',
        emoji: emoji || '🛍️',
        estoque: Number(estoque),
        ativo,
        atualizado_em: new Date().toISOString(),
      })
      .eq('id', id)
      .select()
      .single()

    if (error) throw error

    return res.json({
      mensagem: 'Produto atualizado com sucesso!',
      produto: data,
    })
    } catch (error) {
    console.error('Erro ao atualizar produto:', error)

    return res.status(500).json({
      erro: 'Não foi possível atualizar o produto.',
    })
  }
})

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`)
})
