# Remover pedidos de desenvolvimento e a seção de testes

Alteração autorizada pelo usuário em 11/11/2026.

## Painel
Removida a seção Pedidos de teste da navegação, seu carregamento e a rota de listagem específica da API. A seção Pedidos permanece. As proteções internas de pagamento/reserva para registros marcados como teste continuam, sem criar uma categoria no painel.

## Limpeza pontual autorizada
Arquivo: `supabase/operacoes/limpar_pedidos_desenvolvimento_autorizados.sql`.
Não é migration e não é executado pelo instalador.

O usuário confirmou que TODOS os pedidos existentes eram de desenvolvimento, inclusive os não marcados como teste, e autorizou sua exclusão. O script abrange somente pedidos criados até 11/11/2026 05:42:51 UTC (02:42:51 de Brasília), limite fixo da preparação desta operação. Pedidos posteriores ficam preservados.

O SQL:
- Faz backup integral de pedidos, itens e reservas selecionados em `karen_backup_privado.limpeza_pedidos_desenvolvimento`, sem acesso concedido aos papéis da aplicação.
- Registra os estoques de produtos e variações para conferência.
- Libera reservas pendentes e exclui as reservas e itens vinculados, depois os pedidos selecionados.
- Não modifica produtos, variações, categorias, estoque físico ou numeração de pedidos.
- Usa transação. Se houver erro ou alteração inesperada no inventário, reverte toda a operação. Dependências desconhecidas não são apagadas em cascata: causam falha e reversão.
- Pode ser repetido sem remover pedidos novos: a execução fica registrada pelo identificador fixo da operação.
- Atua apenas no banco. Não faz chamadas ao Mercado Pago nem cancela cobranças no provedor.

A limpeza remota AINDA NÃO foi executada nesta entrega. O SQL foi validado em PostgreSQL isolado.

## Instalação do painel
Envie `karen-remover-pedidos-teste-patch.zip` para `/workspaces/karen-beauty-shop` no Codespaces e execute:

```bash
PASTA_PATCH="$(mktemp -d /workspaces/karen-pedidos-XXXXXX)"
unzip -n /workspaces/karen-beauty-shop/karen-remover-pedidos-teste-patch.zip -d "$PASTA_PATCH" &&
node "$PASTA_PATCH/aplicar-limpeza-pedidos.mjs" /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
```

Este patch parte da interface v2 já instalada. Antes de gravar, confere os arquivos e para se encontrar alterações locais. Cria backup dos arquivos substituídos e não toca nas configurações ou no banco.

```bash
cd /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop
npm test && npm run build
```

Reinicie os dois servidores nessa pasta e atualize o painel. Mantenha o túnel do Windows aberto.

## Executar a limpeza já autorizada
No Codespaces, abra o arquivo SQL pelo explorador de arquivos ou execute:

```bash
cat /workspaces/karen-atualizado-2aSQhl/karen-beauty-shop/supabase/operacoes/limpar_pedidos_desenvolvimento_autorizados.sql
```

Copie TODO o conteúdo para uma nova consulta no SQL Editor do Supabase e execute como administrador do banco. O resultado retorna contagens de pedidos, itens e reservas excluídos e confirma o backup. Se houver erro, envie a mensagem sem dados pessoais; não remova proteções para forçar a limpeza.

Depois, reabra a Henna no painel, confira 4 Rosa + 4 Preto, estoque original 8 e diferença zero, e clique em Ativar variações no catálogo. A conversão é uma ação separada; esta limpeza não altera estoques nem converte produtos automaticamente.

## Validação
30 testes aprovados, incluindo limpeza com rollback por dependência inesperada, backup privado, preservação integral do inventário e de pedidos posteriores, repetição segura e conversão desbloqueada após limpeza. TypeScript e build aprovados.
