
import { useEffect, useMemo, useState } from 'react'
import { products, type Product } from './products'
import './App.css'

type CartItem = {
  product: Product
  quantity: number
}

function money(value: number) {
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  })
}

function App() {
  const [category, setCategory] = useState('Todos')
  const [search, setSearch] = useState('')
  const [cart, setCart] = useState<CartItem[]>([])
  const [catalogo, setCatalogo] = useState<Product[]>(products)
  const [cartOpen, setCartOpen] = useState(false)
const [checkoutOpen, setCheckoutOpen] = useState(false)
  useEffect(() => {
    fetch('/api/produtos').then(r => r.ok ? r.json() : Promise.reject()).then(data => {
      if (Array.isArray(data.produtos)) setCatalogo(data.produtos)
    }).catch(() => undefined)
  }, [])
  const categories = useMemo(() => ['Todos', ...Array.from(new Set(catalogo.map(p => p.category).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'pt-BR'))], [catalogo])
  const filteredProducts = useMemo(() => {
    return catalogo.filter(product => {
      const matchesCategory =
        category === 'Todos' || product.category === category

      const matchesSearch =
        product.name.toLowerCase().includes(search.toLowerCase())

      return matchesCategory && matchesSearch
    })
  }, [catalogo, category, search])

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  const total = cart.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  )

  function addToCart(product: Product) {
    setCart(current => {
      const existing = current.find(item => item.product.id === product.id)

      if (existing) {
        return current.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }

      return [...current, { product, quantity: 1 }]
    })
    setCartOpen(true)
  }

  function changeQuantity(productId: number, amount: number) {
    setCart(current =>
      current
        .map(item =>
          item.product.id === productId
            ? { ...item, quantity: item.quantity + amount }
            : item
        )
        .filter(item => item.quantity > 0)
    )
  }

  function removeItem(productId: number) {
    setCart(current =>
      current.filter(item => item.product.id !== productId)
    )
  }

  return (
    <div className="store">
      <div className="top-strip">
        ✨ Beleza, cuidado e autoestima em um só lugar
      </div>

      <header className="header">
        <a className="brand" href="#inicio">
          <span className="brand-mark">K</span>
          <span>
            <strong>Karen Beauty Shop</strong>
            <small>BELEZA EM CADA DETALHE</small>
          </span>
        </a>

        <nav className="desktop-nav">
          <a href="#inicio">Início</a>
          <a href="#produtos">Produtos</a>
          <a href="#categorias">Categorias</a>
        </nav>

        <button className="cart-button" onClick={() => setCartOpen(true)}>
          ♡ Carrinho <span>{cartCount}</span>
        </button>
      </header>

      <main>
        <section className="hero" id="inicio">
          <div className="hero-copy">
            <span className="eyebrow">
              SUA ROTINA DE BELEZA COMEÇA AQUI
            </span>
            <h1>
              Realce sua beleza.
              <br />
              <em>Cuide de você.</em>
            </h1>
            <p>
              Encontre seus produtos favoritos de beleza, maquiagem e
              cuidados pessoais em um só lugar.
            </p>
            <a href="#produtos" className="primary-button">
              Descobrir produtos <span>→</span>
            </a>
            <div className="hero-note">♡ Escolhas especiais para você</div>
          </div>

          <div className="hero-art">
            <div className="hero-circle">
              <span className="hero-flower">✿</span>
              <span className="hero-k">K</span>
              <span className="hero-caption">BEAUTY & CARE</span>
            </div>
            <span className="decor decor-one">✧</span>
            <span className="decor decor-two">♡</span>
          </div>
        </section>

        <section className="benefits">
          <div>
            <span>♡</span>
            <p>
              <strong>Beleza e cuidado</strong>
              <small>Produtos selecionados</small>
            </p>
          </div>
          <div>
            <span>✧</span>
            <p>
              <strong>Compra prática</strong>
              <small>Peça sem sair de casa</small>
            </p>
          </div>
          <div>
            <span>⌂</span>
            <p>
              <strong>Entrega nacional</strong>
              <small>Consulte as condições</small>
            </p>
          </div>
        </section>

        <section className="categories-section" id="categorias">
          <div className="section-heading">
            <span className="eyebrow">EXPLORE A LOJA</span>
            <h2>Encontre o que você procura</h2>
          </div>

          <div className="category-list">
            {categories.map(item => (
              <button
                key={item}
                className={
                  category === item
                    ? 'category-chip active'
                    : 'category-chip'
                }
                onClick={() => setCategory(item)}
              >
                {item}
              </button>
            ))}
          </div>
        </section>

        <section className="products-section" id="produtos">
          <div className="products-heading">
            <div>
              <span className="eyebrow">SELEÇÃO KAREN BEAUTY</span>
              <h2>Nossos produtos</h2>
            </div>
            <span className="product-count">
              {filteredProducts.length} produtos
            </span>
          </div>

          <div className="search-box">
            <span>⌕</span>
            <input
              value={search}
              onChange={event => setSearch(event.target.value)}
              placeholder="Buscar produtos..."
            />
          </div>

          <div className="product-grid">
            {filteredProducts.map(product => (
              <article className="product-card" key={product.id}>
                <div className="product-image">
                  {product.imagem ? <img src={product.imagem} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span className="product-emoji">{product.emoji}</span>}
                  <button className="favorite" aria-label="Favoritar">
                    ♡
                  </button>
                </div>

                <div className="product-info">
                  <small>{product.category}</small>
                  <h3>{product.name}</h3>
                  <p>{product.description}</p>

                  <div className="price-line">
                    <strong>{money(product.price)}</strong>
                  </div>

                  <button
                    className="add-button"
                    onClick={() => addToCart(product)}
                  >
                    Adicionar ao carrinho +
                  </button>
                </div>
              </article>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <p className="empty">
              Nenhum produto encontrado. Tente outra busca.
            </p>
          )}
        </section>

        <section className="closing-banner">
          <span>UM CARINHO ESPECIAL PARA VOCÊ</span>
          <h2>Sua beleza merece esse cuidado.</h2>
          <a href="#produtos">Conhecer produtos →</a>
        </section>
      </main>

      <footer className="footer">
        <div className="brand footer-brand">
          <span className="brand-mark">K</span>
          <span>
            <strong>Karen Beauty Shop</strong>
            <small>BELEZA EM CADA DETALHE</small>
          </span>
        </div>
        <p>Beleza, cuidado e autoestima em cada escolha.</p>
        <small>© 2026 Karen Beauty Shop. Todos os direitos reservados.</small>
      </footer>

{checkoutOpen && (
  <div className="checkout-overlay">
    <section className="checkout-panel">
      <div className="checkout-heading">
        <div>
          <span className="eyebrow">KAREN BEAUTY SHOP</span>
          <h2>Finalizar pedido</h2>
          <p>Informe seus dados para continuar.</p>
        </div>
        <button
          className="cart-close"
          onClick={() => setCheckoutOpen(false)}
          type="button"
        >
          ×
        </button>
      </div>

      <form
        className="checkout-form"
        onSubmit={async event => {
  event.preventDefault()

  const formData = new FormData(event.currentTarget)

  const pedido = {
    nome: String(formData.get('nome') || ''),
    whatsapp: String(formData.get('whatsapp') || ''),
    email: String(formData.get('email') || ''),
    tipo_entrega: String(formData.get('delivery') || 'delivery'),
    cep: String(formData.get('cep') || ''),
    cidade: String(formData.get('cidade') || ''),
    estado: String(formData.get('estado') || ''),
    endereco: String(formData.get('endereco') || ''),
    numero: String(formData.get('numero') || ''),
    complemento: String(formData.get('complemento') || ''),
    bairro: String(formData.get('bairro') || ''),
    itens: cart.map(item => ({
      produto_id: item.product.id,
      quantidade: item.quantity
    }))
  }

  try {
    const resposta = await fetch(`${API_URL}/api/pedidos`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(pedido)
    })

    const resultado = await resposta.json()

    if (!resposta.ok) {
      alert(resultado.erro || 'Não foi possível registrar o pedido.')
      return
    }

    alert(
      `Pedido nº ${resultado.pedido.numero} registrado com sucesso!`
    )

    setCart([])
    setCheckoutOpen(false)
  } catch {
    alert('Não foi possível conectar ao servidor. Tente novamente.')
  }
}}
      >
        <h3>Seus dados</h3>

        <label>Nome completo</label>
        <input
  required
  name="nome"
  placeholder="Digite seu nome completo"
/>

        <label>WhatsApp</label>
        <input
  required
  name="whatsapp"
  type="tel"
  placeholder="(88) 99999-9999"
/>
<label>E-mail</label>
<input
  required
  name="email"
  type="email"
  placeholder="seuemail@gmail.com"
  autoComplete="email"
/>
        <h3>Como deseja receber?</h3>

        <label className="delivery-option">
          <input type="radio" name="delivery" value="delivery" defaultChecked />
          Entrega no endereço
        </label>

        <label className="delivery-option">
          <input type="radio" name="delivery" value="pickup" />
          Retirar na loja
        </label>

        <h3>Endereço de entrega</h3>

        <label>cep</label>
        <input placeholder="00000-000" />

        <div className="checkout-fields">
          <div>
            <label>cidade</label>
            <input placeholder="Sua cidade" />
          </div>
          <div>
            <label>estado</label>
            <input placeholder="CE" maxLength={2} />
          </div>
        </div>

        <label>endereco</label>
        <input placeholder="Nome da rua" />

        <div className="checkout-fields">
          <div>
            <label>numero</label>
            <input placeholder="Número" />
          </div>
          <div>
            <label>complemento</label>
            <input placeholder="Opcional" />
          </div>
        </div>

        <label>bairro</label>
        <input placeholder="Seu bairro" />

        <button className="checkout-button" type="submit">
          Continuar →
        </button>

        <button
          className="continue-button"
          type="button"
          onClick={() => setCheckoutOpen(false)}
        >
          Voltar para a loja
        </button>
      </form>
    </section>
  </div>
)}

      {cartOpen && (
        <div className="cart-overlay" onClick={() => setCartOpen(false)}>
          <aside
            className="cart-drawer"
            onClick={event => event.stopPropagation()}
          >
            <div className="cart-header">
              <div>
                <span className="eyebrow">SUA SACOLA</span>
                <h2>Meu carrinho ({cartCount})</h2>
              </div>
              <button
                className="cart-close"
                onClick={() => setCartOpen(false)}
                aria-label="Fechar carrinho"
              >
                ×
              </button>
            </div>

            {cart.length === 0 ? (
              <div className="cart-empty">
                <span>♡</span>
                <h3>Sua sacola está vazia</h3>
                <p>Adicione seus produtos favoritos para continuar.</p>
                <button
                  className="add-button"
                  onClick={() => setCartOpen(false)}
                >
                  Continuar comprando
                </button>
              </div>
            ) : (
              <>
                <div className="cart-items">
                  {cart.map(item => (
                    <div className="cart-item" key={item.product.id}>
                      <div className="cart-item-image">
                        {item.product.emoji}
                      </div>

                      <div className="cart-item-info">
                        <small>{item.product.category}</small>
                        <strong>{item.product.name}</strong>
                        <span>{money(item.product.price)}</span>

                        <div className="quantity-control">
                          <button
                            onClick={() => changeQuantity(item.product.id, -1)}
                          >
                            −
                          </button>
                          <span>{item.quantity}</span>
                          <button
                            onClick={() => changeQuantity(item.product.id, 1)}
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <button
                        className="remove-item"
                        onClick={() => removeItem(item.product.id)}
                        aria-label="Remover produto"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>

                <div className="cart-summary">
                  <div>
                    <span>Subtotal</span>
                    <strong>{money(total)}</strong>
                  </div>
                  <div>
                    <span>Entrega</span>
                    <span>A calcular</span>
                  </div>
                  <div className="cart-total">
                    <span>Total dos produtos</span>
                    <strong>{money(total)}</strong>
                  </div>
                  <button
  className="checkout-button"
  onClick={() => {
    setCartOpen(false)
    setCheckoutOpen(true)
  }}
>
  Continuar para finalizar →
</button>
                  <button
                    className="continue-button"
                    onClick={() => setCartOpen(false)}
                  >
                    Continuar comprando
                  </button>
                </div>
              </>
            )}
          </aside>
        </div>
      )}
    </div>
  )
}

export default App
const API_URL = ''
