import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const aqui = path.dirname(fileURLToPath(import.meta.url));
const fonte = path.join(aqui, 'karen-beauty-shop');
const argumentos = process.argv.slice(2);
const verificar = argumentos.includes('--verificar');
const destinoInformado = argumentos.find(a => !a.startsWith('--'));
if (!destinoInformado) {
  console.error('Uso: node aplicar-atualizacao.mjs /workspaces/karen-beauty-shop [--verificar]');
  process.exit(1);
}
const destino = fs.realpathSync(destinoInformado);
const manifesto = JSON.parse(fs.readFileSync(path.join(aqui, 'atualizacao-manifesto.json'), 'utf8'));
const hash = dados => crypto.createHash('sha256').update(dados).digest('hex');
function caminhoSeguro(raiz, relativo) {
  if (typeof relativo !== 'string' || relativo.includes('\\') || path.posix.isAbsolute(relativo) ||
      relativo.split('/').some(p => !p || p === '.' || p === '..') ||
      relativo.split('/').some(p => ['.git','node_modules'].includes(p)) ||
      (path.posix.basename(relativo).startsWith('.env') && path.posix.basename(relativo) !== '.env.example')) {
    throw new Error('Caminho não permitido no manifesto.');
  }
  const absoluto = path.resolve(raiz, ...relativo.split('/'));
  if (!absoluto.startsWith(raiz + path.sep)) throw new Error('Caminho fora da pasta de destino.');
  let componente = raiz;
  for (const parte of relativo.split('/')) {
    componente = path.join(componente, parte);
    try {
      if (fs.lstatSync(componente).isSymbolicLink()) throw new Error(`Link simbólico não permitido: ${relativo}`);
    } catch (erro) { if (erro.code !== 'ENOENT') throw erro; }
  }
  return absoluto;
}
if (!fs.existsSync(path.join(destino, 'package.json')) || !fs.existsSync(path.join(destino, 'server'))) {
  throw new Error('A pasta informada não parece ser o projeto Karen Beauty Shop.');
}
if (destino === fonte || destino.startsWith(fonte + path.sep) || fonte.startsWith(destino + path.sep)) {
  throw new Error('Extraia o ZIP em uma pasta temporária FORA do projeto antes de aplicar.');
}

const conflitos = [];
const planos = [];
let preservados = 0;
let prontos = 0;
for (const entrada of manifesto.arquivos) {
  const origem = caminhoSeguro(fonte, entrada.caminho);
  const alvo = caminhoSeguro(destino, entrada.caminho);
  const dados = fs.readFileSync(origem);
  if (hash(dados) !== entrada.novo) throw new Error(`Arquivo da atualização divergente: ${entrada.caminho}`);
  const existe = fs.existsSync(alvo);
  const atual = existe && fs.lstatSync(alvo).isFile() ? hash(fs.readFileSync(alvo)) : null;
  if (atual === entrada.novo) { prontos++; continue; }
  // Arquivos não modificados pela correção mantêm eventuais edições locais.
  if (entrada.anterior === entrada.novo && existe && fs.lstatSync(alvo).isFile()) {
    preservados++; continue;
  }
  if ((!existe && entrada.anterior === null) || (atual !== null && atual === entrada.anterior)) {
    planos.push({ ...entrada, origem, alvo, existia: existe });
  } else conflitos.push(entrada.caminho);
}
if (conflitos.length) {
  console.error('ATUALIZAÇÃO INTERROMPIDA. Nenhum arquivo foi alterado.');
  console.error('Estes arquivos diferem da versão enviada para revisão ou estão ausentes:');
  for (const nome of conflitos) console.error(`- ${nome}`);
  console.error('Preserve essas alterações e solicite a mesclagem antes de continuar.');
  process.exit(2);
}
console.log(`Conferência: ${planos.length} arquivos para atualizar; ${prontos} já estão corretos; ${preservados} com edições locais preservadas.`);
if (verificar || planos.length === 0) {
  console.log(verificar ? 'Somente verificação: nenhum arquivo foi alterado.' : 'O projeto já recebeu esta atualização.');
  process.exit(0);
}

const backup = path.join(path.dirname(destino), `${path.basename(destino)}-backup-${new Date().toISOString().replace(/[:.]/g, '-')}-${crypto.randomUUID().slice(0,8)}`);
fs.mkdirSync(backup, { recursive: false });
// Copia todos os arquivos substituídos antes da primeira alteração no projeto.
for (const plano of planos) {
  if (plano.existia) {
    const copia = caminhoSeguro(backup, plano.caminho);
    fs.mkdirSync(path.dirname(copia), { recursive: true });
    fs.copyFileSync(plano.alvo, copia);
  }
}
fs.writeFileSync(path.join(backup, 'registro-atualizacao.json'), JSON.stringify({
  destino, criadoEm: new Date().toISOString(), arquivos: planos.map(p => ({ caminho: p.caminho, existia: p.existia }))
}, null, 2));

const aplicados = [];
try {
  for (const plano of planos) {
    // Detecta também alterações feitas depois da conferência inicial.
    const atual = fs.existsSync(plano.alvo) ? hash(fs.readFileSync(plano.alvo)) : null;
    if (atual !== plano.anterior) throw new Error(`Arquivo mudou durante a atualização: ${plano.caminho}`);
    fs.mkdirSync(path.dirname(plano.alvo), { recursive: true });
    aplicados.push(plano);
    fs.copyFileSync(plano.origem, plano.alvo);
    if (hash(fs.readFileSync(plano.alvo)) !== plano.novo) throw new Error(`Falha ao conferir: ${plano.caminho}`);
  }
} catch (erro) {
  for (const plano of aplicados.reverse()) {
    if (plano.existia) fs.copyFileSync(caminhoSeguro(backup, plano.caminho), plano.alvo);
    else if (fs.existsSync(plano.alvo)) fs.unlinkSync(plano.alvo);
  }
  console.error(`A aplicação falhou; os arquivos substituídos foram restaurados. Backup: ${backup}`);
  throw erro;
}
console.log(`Atualização aplicada em: ${destino}`);
console.log(`Backup dos arquivos anteriores: ${backup}`);
console.log('.env.local, .git, node_modules e arquivos extras foram preservados. Nenhum comando de banco foi executado.');
console.log('Próximo passo: npm ci, npm test e npm run build. Não aplique migrations no banco remoto ainda.');
