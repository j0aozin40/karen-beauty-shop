import type { Product } from '../src/products.ts'

type VariationPrice = { id: string; preco: number | string; preco_promocional: number | string | null }

// O agrupamento é interno. Cada opção publicada possui uma identidade de compra própria.
export function vitrineVariacoes(grupos: Product[]): Product[] {
  const opcoes = new Map<string, Product>()
  for (const grupo of grupos) {
    if (!grupo.controla_variacoes) {
      opcoes.set(`${grupo.id}:`, { ...grupo, variacoes: undefined, variacao_principal_id: undefined })
      continue
    }
    for (const opcao of grupo.variacoes || []) {
      const item: Product = {
        ...grupo, name: `${grupo.name} — ${opcao.nome}`, familyName: grupo.name,
        variationId: opcao.id, variationName: opcao.nome, variationType: opcao.tipo,
        price: Number(opcao.price), stock: Number(opcao.stock),
        imagem: opcao.imagem || grupo.imagem,
        variacoes: undefined, variacao_principal_id: undefined,
      }
      opcoes.set(`${grupo.id}:${opcao.id}`, item)
    }
  }
  return [...opcoes.values()]
}

export function anexarPrecosPromocionais(produtos: Product[], precos: VariationPrice[]): Product[] {
  const porId = new Map(precos.map(preco => [preco.id, preco]))
  return produtos.map(produto => {
    if (!produto.variationId) return produto
    const preco = porId.get(produto.variationId)
    if (!preco) return produto
    const original = Number(preco.preco)
    const promocional = preco.preco_promocional == null ? null : Number(preco.preco_promocional)
    if (!Number.isFinite(original)) return produto
    if (promocional !== null && Number.isFinite(promocional) && promocional < original) {
      return { ...produto, price: promocional, originalPrice: original, discountPercent: Math.max(1, Math.round((original - promocional) / original * 100)) }
    }
    return { ...produto, price: promocional !== null && Number.isFinite(promocional) ? promocional : original, originalPrice: undefined, discountPercent: undefined }
  })
}
